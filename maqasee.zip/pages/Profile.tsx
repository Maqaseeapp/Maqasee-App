import React, { useEffect, useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { Card, Button, useToast, Input, Loading } from '../components/UI';
import { AppLayout } from '../components/Layout';
import { useNavigate } from 'react-router-dom';
import { auth } from '../firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { 
  getUserProfile, 
  getProfile, 
  deleteProfile, 
  updateActiveProfile, 
  updateProfileMeta, 
  updateUserUnits,
  updateProfileMeasurements,
  updateNotificationSettings
} from '../services/firestore';
import { UserProfile, Measurements, Profile as UserSubProfile, Relationship, UnitSystem, Gender, NotificationSettings } from '../types';
import { ICONS, COLORS } from '../constants';
import { getGlobalPassportSizes } from '../services/sizeEngine';

export const Profile: React.FC = () => {
  const { t, isRTL } = useLanguage();
  const { showToast } = useToast();
  const navigate = useNavigate();
  const [user, setUser] = useState<UserProfile | null>(null);
  const [profile, setProfile] = useState<UserSubProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [isEditingMeta, setIsEditingMeta] = useState(false);
  const [isEditingVault, setIsEditingVault] = useState(false);
  const [uid, setUid] = useState<string | null>(null);

  const [editName, setEditName] = useState('');
  const [editType, setEditType] = useState<Relationship>('self');
  const [editGender, setEditGender] = useState<Gender>('women');
  const [vaultValues, setVaultValues] = useState<Measurements>({});
  
  const [notificationSettings, setNotificationSettings] = useState<NotificationSettings>({
    appUpdates: true,
    measurementReminders: true,
    featureAnnouncements: false
  });

  const getAvatarColor = (name: string) => {
    const hash = name.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    const colors = [COLORS.yellow, COLORS.pink, COLORS.sage, COLORS.salmon];
    return colors[hash % colors.length];
  };

  const loadData = async (userId: string) => {
    const userData = await getUserProfile(userId);
    setUser(userData);
    if (userData?.notificationSettings) {
        setNotificationSettings(userData.notificationSettings);
    }
    if (userData?.activeProfileId) {
      const p = await getProfile(userId, userData.activeProfileId);
      setProfile(p);
      if (p) {
        setEditName(p.name);
        setEditType(p.type || 'self');
        setEditGender(p.gender || 'women');
        setVaultValues(p.measurements);
      }
    }
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      if (fbUser) {
        setUid(fbUser.uid);
        await loadData(fbUser.uid);
      } else {
        navigate('/auth');
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, [navigate]);

  const handleUnitToggle = async (unit: UnitSystem) => {
    if (!uid) return;
    await updateUserUnits(uid, unit);
    setUser(prev => prev ? { ...prev, unitPreference: unit } : null);
    showToast(`${t('units')}: ${t(unit as any)}`);
  };

  const handleNotificationToggle = async (key: keyof NotificationSettings) => {
    if (!uid) return;
    const newSettings = {
      ...notificationSettings,
      [key]: !notificationSettings[key]
    };
    setNotificationSettings(newSettings);
    await updateNotificationSettings(uid, newSettings);
  };

  const handleSaveMeta = async () => {
    if (uid && profile) {
      await updateProfileMeta(uid, profile.id, { 
        name: editName, 
        type: editType, 
        gender: editGender 
      });
      setProfile({ ...profile, name: editName, type: editType, gender: editGender });
      setIsEditingMeta(false);
      showToast(t('successSave'));
    }
  };

  const toDisplayValue = (cm: number | undefined, field: string) => {
    if (cm === undefined || cm === null) return '';
    if (user?.unitPreference === 'imperial') {
      if (field.includes('kg')) return (cm * 2.20462).toFixed(1);
      return (cm / 2.54).toFixed(1);
    }
    return cm.toString();
  };

  const fromDisplayValue = (val: string, field: string) => {
    const num = parseFloat(val);
    if (isNaN(num)) return undefined;
    if (user?.unitPreference === 'imperial') {
      if (field.includes('kg')) return num / 2.20462;
      return num * 2.54;
    }
    return num;
  };

  const handleSaveVault = async () => {
    if (!uid || !profile) return;
    try {
      await updateProfileMeasurements(uid, profile.id, vaultValues);
      setProfile({ ...profile, measurements: vaultValues });
      setIsEditingVault(false);
      showToast(t('vaultUpdated'));
    } catch (err) {
      console.error(err);
    }
  };

  const handleResetDNA = async () => {
    if (!uid || !profile) return;
    try {
      const empty: Measurements = {};
      await updateProfileMeasurements(uid, profile.id, empty);
      setVaultValues(empty);
      setProfile({ ...profile, measurements: empty });
      setShowResetConfirm(false);
      showToast(t('successSave'));
    } catch (err) {
      console.error(err);
    }
  };

  const handleDelete = async () => {
    if (!profile || !uid) return;
    try {
      await deleteProfile(uid, profile.id);
      await updateActiveProfile(uid, 'myself');
      navigate('/app');
    } catch (err) {
      console.error(err);
    }
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-[#F7F1E5]">
      <Loading />
    </div>
  );

  const categories = [
    { title: t('torso'), fields: ['neck_cm', 'chest_cm', 'waist_cm', 'shoulder_cm', 'sleeve_cm'] },
    { title: t('lowerBody'), fields: ['hips_cm', 'inseam_cm', 'thigh_cm'] },
    { title: t('general'), fields: ['height_cm', 'weight_kg', 'foot_cm'] }
  ];

  const passport = profile ? getGlobalPassportSizes(profile.measurements) : null;

  return (
    <AppLayout>
      <div className="space-y-8 pb-12">
        <header className="flex justify-between items-center px-2">
          <h1 className="text-2xl font-bold text-black">{t('profile')}</h1>
          <div className="flex space-x-2 rtl:space-x-reverse">
             <Button variant="secondary" onClick={() => setIsEditingVault(!isEditingVault)} className="!px-4 !py-2 !text-[10px]">
                {isEditingVault ? t('save') : t('editProfile')}
             </Button>
          </div>
        </header>

        <Card className="relative p-0 overflow-hidden" bgColor="bg-white">
           {!isEditingMeta ? (
             <div className="p-6 flex flex-col space-y-6">
               <div className="flex items-center justify-between">
                 <div className="flex items-center space-x-4 rtl:space-x-reverse">
                   <div 
                     className="w-16 h-16 rounded-[1.75rem] flex items-center justify-center text-2xl font-black text-white shadow-lg"
                     style={{ backgroundColor: profile ? getAvatarColor(profile.name) : COLORS.salmon }}
                   >
                     {profile?.name.charAt(0).toUpperCase()}
                   </div>
                   <div className="space-y-1">
                      <h2 className="text-xl font-black text-zinc-900 tracking-tight">{profile?.name}</h2>
                      <div className="flex items-center space-x-2 rtl:space-x-reverse">
                         <span className="px-2 py-0.5 bg-zinc-100 text-zinc-500 rounded-full text-[8px] font-black uppercase tracking-widest">{t(profile?.type || 'self')}</span>
                         <span className="px-2 py-0.5 bg-zinc-100 text-zinc-500 rounded-full text-[8px] font-black uppercase tracking-widest">{t(profile?.gender || 'women')}</span>
                      </div>
                   </div>
                 </div>
                 <button onClick={() => setIsEditingMeta(true)} className="p-2 text-zinc-400 hover:text-black transition-colors">
                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                    </svg>
                 </button>
               </div>

               <Button 
                variant="ghost" 
                onClick={() => navigate('/app/compare')} 
                className="!text-[9px] !tracking-[0.25em] bg-zinc-50/50 hover:bg-zinc-100 border-dashed border-zinc-200"
               >
                 {t('compare')}
               </Button>
             </div>
           ) : (
             <div className="p-8 space-y-6 animate-in slide-in-from-top-4 duration-300">
                <Input label={t('profileName')} value={editName} onChange={(e) => setEditName(e.target.value)} />
                
                <div className="space-y-3">
                  <label className="text-[10px] font-black uppercase tracking-widest text-zinc-500 px-1">{t('gender')}</label>
                  <div className="grid grid-cols-2 gap-3">
                    {(['men', 'women'] as Gender[]).map(g => (
                      <button
                        key={g}
                        onClick={() => setEditGender(g)}
                        className={`py-4 rounded-3xl text-[10px] font-black uppercase transition-all shadow-sm ${editGender === g ? 'bg-[#F1B95B] text-white shadow-md' : 'bg-zinc-50 text-zinc-400 border border-zinc-100'}`}
                      >
                        {t(g as any)}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <label className="text-[10px] font-black uppercase tracking-widest text-zinc-500 px-1">{t('relationship')}</label>
                  <div className="grid grid-cols-3 gap-3">
                    {(['self', 'friend', 'family'] as Relationship[]).map(r => (
                      <button
                        key={r}
                        onClick={() => setEditType(r)}
                        className={`py-4 rounded-3xl text-[10px] font-black uppercase transition-all shadow-sm ${editType === r ? 'bg-[#F1B95B] text-white shadow-md' : 'bg-zinc-50 text-zinc-400 border border-zinc-100'}`}
                      >
                        {t(r as any)}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex space-x-3 rtl:space-x-reverse pt-2">
                   <Button onClick={handleSaveMeta} fullWidth>{t('save')}</Button>
                   <Button variant="secondary" onClick={() => setIsEditingMeta(false)}>{t('cancel')}</Button>
                </div>
             </div>
           )}
        </Card>

        {passport && (
          <div className="relative group">
            <div className="absolute -inset-1 bg-gradient-to-r from-blue-100 to-green-100 rounded-[3rem] blur opacity-25"></div>
            <Card className="relative p-8 space-y-6 border border-blue-50/50" bgColor="bg-white/80" hasBlur={true}>
               <div className="flex justify-between items-center">
                 <div className="flex items-center space-x-4 rtl:space-x-reverse">
                   <div className="w-10 h-10 shrink-0 drop-shadow-lg transition-transform duration-500 group-hover:scale-110">
                     {ICONS.passport("w-full h-full")}
                   </div>
                   <div className="space-y-1">
                      <h3 className="text-[10px] font-black uppercase tracking-[0.25em] text-zinc-500">{t('globalPassport')}</h3>
                      <h2 className="text-xl font-black text-zinc-900 tracking-tight">{t('internationalSizes')}</h2>
                   </div>
                 </div>
                 <div className="px-3 py-1 bg-green-100/50 text-green-700 text-[8px] font-black uppercase rounded-full tracking-[0.2em] border border-green-200/50">{t('verifiedFit')}</div>
               </div>
               
               <div className="grid grid-cols-2 gap-4">
                  {[
                    { id: 'us', val: passport.us },
                    { id: 'uk', val: passport.uk },
                    { id: 'eu', val: passport.eu },
                    { id: 'jp', val: passport.jp }
                  ].map(item => (
                    <div key={item.id} className="bg-zinc-50/50 p-5 rounded-[2rem] border border-zinc-100/50 flex flex-col items-center group/item hover:bg-white hover:shadow-lg hover:shadow-zinc-900/[0.02] transition-all">
                       <span className="text-[9px] font-black uppercase text-zinc-400 tracking-widest mb-2 group-hover/item:text-zinc-600 transition-colors">{t(item.id as any)}</span>
                       <span className="text-2xl font-black text-zinc-800 tracking-tighter">{item.val}</span>
                    </div>
                  ))}
               </div>
            </Card>
          </div>
        )}

        <Card className="flex items-center justify-between p-5" bgColor="bg-white">
           <span className="text-[10px] font-black uppercase text-zinc-600 tracking-widest">{t('units')}</span>
           <div className="flex bg-zinc-200/40 p-1 rounded-full border border-zinc-200/60">
              {(['metric', 'imperial'] as UnitSystem[]).map(u => (
                <button
                  key={u}
                  onClick={() => handleUnitToggle(u)}
                  className={`px-5 py-2 rounded-full text-[9px] font-black uppercase transition-all ${user?.unitPreference === u ? 'bg-[#F1B95B] text-white shadow-md' : 'text-zinc-400'}`}
                >
                  {t(u as any)}
                </button>
              ))}
           </div>
        </Card>

        <div className="space-y-4">
            <h3 className="text-[10px] font-black uppercase tracking-[0.3em] text-zinc-600 px-2">{t('notificationSettings')}</h3>
            <Card className="p-6 space-y-6" bgColor="bg-white">
                <div className="space-y-2 mb-4">
                    <p className="text-xs text-zinc-500 font-medium">{t('manageNotifications')}</p>
                </div>
                {[
                    { key: 'appUpdates', label: t('appUpdates') },
                    { key: 'measurementReminders', label: t('measurementReminders') },
                    { key: 'featureAnnouncements', label: t('featureAnnouncements') }
                ].map((item) => (
                    <div key={item.key} className="flex items-center justify-between py-2 border-b border-zinc-50 last:border-0">
                        <span className="text-sm font-bold text-zinc-800">{item.label}</span>
                        <button 
                            onClick={() => handleNotificationToggle(item.key as keyof NotificationSettings)}
                            className={`relative w-12 h-6 rounded-full transition-colors duration-300 ${notificationSettings[item.key as keyof NotificationSettings] ? 'bg-[#F08A82]' : 'bg-zinc-200'}`}
                        >
                            <div className={`absolute top-1 left-1 w-4 h-4 bg-white rounded-full transition-transform duration-300 ${notificationSettings[item.key as keyof NotificationSettings] ? 'translate-x-6' : 'translate-x-0'}`} />
                        </button>
                    </div>
                ))}
            </Card>
        </div>

        <div className="space-y-8">
          <div className="flex justify-between items-center px-2">
            <h3 className="text-[10px] font-black uppercase tracking-[0.3em] text-zinc-600">{t('bodyVault')}</h3>
            {isEditingVault && (
              <button onClick={handleSaveVault} className="text-[10px] font-black uppercase text-green-600 tracking-widest animate-pulse">
                {t('save')}
              </button>
            )}
          </div>
          {categories.map((cat, idx) => (
            <div key={idx} className="space-y-4">
              <h4 className="text-[10px] font-black uppercase tracking-widest px-2 text-zinc-400">{cat.title}</h4>
              <div className="grid grid-cols-2 gap-4">
                {cat.fields.map((field) => {
                  const val = vaultValues[field as keyof Measurements];
                  const displayVal = toDisplayValue(val, field);
                  
                  return (
                    <div key={field} className="bg-white p-5 rounded-[2rem] border border-zinc-100/60 shadow-sm flex flex-col space-y-2 hover:border-zinc-200 transition-colors">
                      <span className="text-[10px] font-black uppercase text-zinc-500 tracking-tighter">{t(field.split('_')[0] as any)}</span>
                      <div className="flex items-baseline space-x-1 rtl:space-x-reverse">
                        {isEditingVault ? (
                          <input 
                            type="number"
                            value={displayVal}
                            onChange={(e) => {
                              const v = fromDisplayValue(e.target.value, field);
                              setVaultValues({ ...vaultValues, [field]: v });
                            }}
                            className="bg-zinc-50 w-full text-xl font-black text-zinc-900 border-b-2 border-zinc-200 focus:outline-none focus:border-[#F1B95B] transition-colors"
                          />
                        ) : (
                          <span className="text-2xl font-black text-zinc-900 tracking-tighter">{displayVal || '--'}</span>
                        )}
                        <span className="text-[9px] font-black text-zinc-400 uppercase tracking-widest">
                          {user?.unitPreference === 'imperial' ? (field.includes('kg') ? t('pounds') : t('inches')) : (field.includes('kg') ? t('weightUnit') : t('metricUnit'))}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        <div className="pt-8 space-y-6 px-2">
           {!showResetConfirm ? (
              <button onClick={() => setShowResetConfirm(true)} className="text-[10px] font-black uppercase tracking-[0.25em] text-zinc-400 hover:text-zinc-700 transition-colors border-b border-transparent hover:border-zinc-400">
                {t('resetDNA')}
              </button>
           ) : (
              <Card className="bg-zinc-100 border border-zinc-200 p-8 space-y-6 rounded-[2.5rem]">
                <p className="text-xs font-bold text-zinc-700 leading-relaxed">{t('confirmReset')}</p>
                <div className="flex space-x-4 rtl:space-x-reverse">
                  <Button onClick={handleResetDNA} className="!bg-zinc-900 !text-white !py-3 !text-[10px]">{t('confirm')}</Button>
                  <Button variant="secondary" onClick={() => setShowResetConfirm(false)} className="!py-3 !text-[10px]">{t('cancel')}</Button>
                </div>
              </Card>
           )}

          {profile?.id !== 'myself' && (
            <div className="block pt-2">
              {!showDeleteConfirm ? (
                <button 
                  onClick={() => setShowDeleteConfirm(true)}
                  className="text-[10px] font-black uppercase tracking-[0.25em] text-pink-500 hover:text-pink-700 transition-colors underline decoration-2 underline-offset-4"
                >
                  {t('deleteProfile')}
                </button>
              ) : (
                <Card className="bg-pink-50/50 border border-pink-100 p-8 space-y-6 animate-in slide-in-from-bottom-4 duration-300 rounded-[2.5rem]">
                  <div className="space-y-2">
                    <h4 className="text-sm font-black text-pink-700 uppercase tracking-widest">{t('confirmDelete')}</h4>
                    <p className="text-xs text-pink-800/70 font-medium leading-relaxed">{t('deleteWarning')}</p>
                  </div>
                  <div className="flex space-x-4 rtl:space-x-reverse">
                    <Button onClick={handleDelete} className="!bg-pink-500 !text-white !py-3 !text-[10px]">{t('confirm')}</Button>
                    <Button variant="secondary" onClick={() => setShowDeleteConfirm(false)} className="!py-3 !text-[10px]">{t('cancel')}</Button>
                  </div>
                </Card>
              )}
            </div>
          )}
        </div>
      </div>
    </AppLayout>
  );
};