import React, { useState, useEffect } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { Card, Button, useToast, Loading } from '../components/UI';
import { AppLayout } from '../components/Layout';
import { SEED_CHARTS, findBestSize } from '../services/sizeEngine';
import { auth } from '../firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { getUserProfile, saveRecommendation, getProfile, getProfiles, getSizeCharts } from '../services/firestore';
import { UserProfile, Profile, Recommendation, SizeChart } from '../types';
import { GoogleGenAI } from "@google/genai";
import { useNavigate } from 'react-router-dom';
import { COLORS } from '../constants';

export const SizeFinder: React.FC = () => {
  const { t, language, isRTL } = useLanguage();
  const { showToast } = useToast();
  const navigate = useNavigate();
  const [platform, setPlatform] = useState('shein');
  const [category, setCategory] = useState('tops');
  const [isGroupMode, setIsGroupMode] = useState(false);
  const [singleResult, setSingleResult] = useState<{ label: string; confidence: number } | null>(null);
  const [groupResults, setGroupResults] = useState<Array<{ profile: Profile; result: { label: string; confidence: number } }>>([]);
  const [aiInsight, setAiInsight] = useState<string>('');
  const [user, setUser] = useState<UserProfile | null>(null);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [activeProfile, setActiveProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [finding, setFinding] = useState(false);
  const [firestoreCharts, setFirestoreCharts] = useState<SizeChart[]>([]);

  const aiIconUrl = "https://i.postimg.cc/Qt6h8Yt7/MAQ-(3).png";

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      if (fbUser) {
        const [userData, allProfiles, dbCharts] = await Promise.all([
          getUserProfile(fbUser.uid),
          getProfiles(fbUser.uid),
          getSizeCharts()
        ]);
        setUser(userData);
        setProfiles(allProfiles);
        setFirestoreCharts(dbCharts);
        if (userData?.activeProfileId) {
          const p = allProfiles.find(x => x.id === userData.activeProfileId);
          setActiveProfile(p || null);
        }
      } else {
        navigate('/auth');
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, [navigate]);

  useEffect(() => {
    if (singleResult && activeProfile) {
      getAIInsight(singleResult.label, singleResult.confidence);
    }
  }, [language]);

  const getAIInsight = async (bestSize: string, confidence: number) => {
    if (!activeProfile) return;
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const systemInstruction = language === 'ar'
        ? "أنت خبير ملاءمة وتصميم ملابس. رد حصراً باللهجة الكويتية العامية. لا تستخدم الفصحى نهائياً ولا تستخدم الإنجليزية. ردك يجب أن يكون قصيراً جداً (جملة واحدة فقط)."
        : "You are a professional fashion advisor. Provide a very brief, 1-sentence fit advice in English.";

      const prompt = `Stats: Height ${activeProfile.measurements.height_cm}cm, Chest ${activeProfile.measurements.chest_cm}cm. Platform: ${platform}, Category: ${category}. Recommended Size: ${bestSize} (${confidence}% match). Give one friendly tip.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: { systemInstruction, temperature: 0.7 }
      });
      setAiInsight(response.text || '');
    } catch (err) {
      console.error(err);
    }
  };

  const handleFind = async () => {
    if (!user) return;
    setFinding(true);
    setSingleResult(null);
    setGroupResults([]);
    setAiInsight('');
    
    await new Promise(r => setTimeout(r, 800));

    const allCharts = [...SEED_CHARTS, ...firestoreCharts];

    if (isGroupMode) {
      const results = profiles.map(p => {
        const gender = p.gender || 'women';
        const chart = allCharts.find(c => c.platform === platform && c.category === category && c.gender === gender) || 
                      allCharts.find(c => c.platform === platform && c.category === category) ||
                      allCharts.find(c => c.platform === platform) || 
                      allCharts[0];
        return {
          profile: p,
          result: findBestSize(p.measurements, chart, p.fitPreference, p.stretchTolerance)
        };
      });
      setGroupResults(results);
      
      for (const entry of results) {
        await saveRecommendation(user.uid, entry.profile.id, {
          platform,
          category: category,
          recommendedSize: entry.result.label,
          confidence: entry.result.confidence
        });
      }
    } else if (activeProfile) {
      const gender = activeProfile.gender || 'women';
      const chart = allCharts.find(c => c.platform === platform && c.category === category && c.gender === gender) || 
                    allCharts.find(c => c.platform === platform && c.category === category) ||
                    allCharts.find(c => c.platform === platform) || 
                    allCharts[0];
      const res = findBestSize(activeProfile.measurements, chart, activeProfile.fitPreference, activeProfile.stretchTolerance);
      setSingleResult(res);
      getAIInsight(res.label, res.confidence);
      await saveRecommendation(user.uid, activeProfile.id, {
        platform,
        category: category,
        recommendedSize: res.label,
        confidence: res.confidence
      });
    }

    setFinding(false);
    showToast(t('feedbackSaved'));
  };

  const getAvatarColor = (name: string) => {
    const hash = name.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    const colors = [COLORS.yellow, COLORS.pink, COLORS.sage, COLORS.salmon];
    return colors[hash % colors.length];
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-zinc-50">
      <Loading />
    </div>
  );

  const hasMeasurements = profiles.some(p => Object.keys(p.measurements).length > 0);
  const currentCharts = [...SEED_CHARTS, ...firestoreCharts];
  const availablePlatforms = Array.from(new Set(currentCharts.map(c => c.platform)));
  const availableCategories = Array.from(new Set(currentCharts.filter(c => c.platform === platform).map(c => c.category)));

  return (
    <AppLayout>
      <div className="space-y-8 pb-12">
        <header className="flex justify-between items-end">
          <div>
            <h1 className="text-2xl font-bold text-black">{t('sizeFinder')}</h1>
            <p className="text-zinc-600 text-sm font-medium">{isGroupMode ? t('sizesForAll') : activeProfile?.name}</p>
          </div>
          <button 
            onClick={() => setIsGroupMode(!isGroupMode)}
            className={`px-4 py-2 rounded-2xl text-[10px] font-black uppercase transition-all shadow-sm ${isGroupMode ? 'bg-[#F1B95B] text-white shadow-md' : 'bg-zinc-100 text-zinc-600 border border-zinc-200'}`}
          >
            {t('groupRecommendation')}
          </button>
        </header>

        {!hasMeasurements ? (
          <Card className="text-center py-12 space-y-4">
             <div className="w-16 h-16 bg-zinc-50 rounded-full mx-auto flex items-center justify-center mb-2">
               <svg className="w-8 h-8 text-zinc-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
             </div>
             <p className="text-zinc-600 font-medium">{t('noData')}</p>
             <Button onClick={() => navigate('/app/profile/new')}>{t('newMeasurement')}</Button>
          </Card>
        ) : (
          <Card className="space-y-6">
            <div className="space-y-3">
              <label className="text-xs font-bold text-zinc-600 uppercase tracking-widest px-1">{t('platform')}</label>
              <div className="flex flex-wrap gap-2">
                {availablePlatforms.map((p) => (
                  <button key={p} onClick={() => { setPlatform(p); setSingleResult(null); setGroupResults([]); setCategory('tops'); }} className={`px-4 py-2.5 rounded-2xl text-xs font-bold capitalize transition-all active:scale-95 ${platform === p ? 'bg-[#F1B95B] text-white shadow-md' : 'bg-zinc-100 text-zinc-600 hover:bg-zinc-200'}`}>{p}</button>
                ))}
              </div>
            </div>

            <div className="space-y-3">
              <label className="text-xs font-bold text-zinc-600 uppercase tracking-widest px-1">{t('categorySelect')}</label>
              <div className="flex flex-wrap gap-2">
                {availableCategories.map((cat) => (
                  <button key={cat} onClick={() => { setCategory(cat); setSingleResult(null); setGroupResults([]); }} className={`px-4 py-2.5 rounded-2xl text-[10px] font-black uppercase transition-all active:scale-95 ${category === cat ? 'bg-[#F1B95B] text-white shadow-md' : 'bg-zinc-100 text-zinc-600 hover:bg-zinc-200'}`}>{t(cat as any)}</button>
                ))}
              </div>
            </div>

            <Button onClick={handleFind} fullWidth disabled={finding}>
              {finding ? t('loading') : (isGroupMode ? t('checkEveryone') : t('findMySize'))}
            </Button>
          </Card>
        )}

        {singleResult && !isGroupMode && (
          <div className="animate-in fade-in slide-in-from-bottom-6 duration-700 ease-out space-y-4">
            <Card className="flex flex-col items-center py-12 space-y-6 overflow-hidden relative" bgColor="bg-[#FDF2F8]">
              <div className="absolute inset-0 bg-gradient-to-b from-white/30 to-transparent pointer-events-none"></div>
              <div className="flex flex-col items-center z-10">
                <span className="text-zinc-600 text-[10px] font-black uppercase tracking-widest mb-2 opacity-80">{t('platform')} {platform} - {t(category as any)}</span>
                <span className="text-9xl font-black text-zinc-900 drop-shadow-sm select-none">{singleResult.label}</span>
              </div>
              <div className="flex flex-col items-center space-y-2 z-10 w-full px-8">
                <div className="flex items-center space-x-3 rtl:space-x-reverse w-full">
                  <div className="flex-1 h-2.5 bg-white/60 rounded-full overflow-hidden">
                    <div className="h-full bg-pink-400 transition-all duration-1000 ease-out" style={{ width: `${singleResult.confidence}%` }}></div>
                  </div>
                  <span className="text-xs font-bold text-zinc-800">{singleResult.confidence}%</span>
                </div>
                <span className="text-[10px] font-black uppercase text-zinc-600 tracking-tighter">{t('confidence')}</span>
              </div>
            </Card>

            <Card className="bg-[#F0FDF4] border border-green-50 p-6 flex items-start justify-between space-x-4 rtl:space-x-reverse rounded-[2.5rem] shadow-sm">
               <div className="w-12 h-12 shrink-0">
                 <img src={aiIconUrl} alt="Maqasee AI" className="w-full h-full object-contain" />
               </div>
               <div className="flex flex-col flex-1 text-left rtl:text-right space-y-2">
                 <h4 className="text-[10px] font-black uppercase text-green-700 tracking-widest">
                   {t('aiInsight')}
                 </h4>
                 <p className="text-sm font-medium text-zinc-700 leading-relaxed">
                   {aiInsight || t('loading')}
                 </p>
               </div>
            </Card>
          </div>
        )}

        {isGroupMode && groupResults.length > 0 && (
          <div className="space-y-4 animate-in fade-in slide-in-from-bottom-6 duration-500">
             <h3 className="text-[10px] font-black uppercase tracking-widest text-zinc-600 px-2">{t('sizesForAll')}</h3>
             <div className="grid grid-cols-1 gap-3">
                {groupResults.map((entry, idx) => (
                  <Card key={idx} className="flex items-center justify-between p-5 border border-zinc-50 hover:border-zinc-200 transition-colors" bgColor="bg-white">
                    <div className="flex items-center space-x-4 rtl:space-x-reverse">
                      <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-lg font-black shadow-inner" style={{ backgroundColor: getAvatarColor(entry.profile.name) }}>
                         {entry.profile.name.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <h4 className="font-black text-sm text-zinc-900">{entry.profile.name}</h4>
                        <p className="text-[9px] font-bold text-zinc-400 uppercase tracking-widest">{t(entry.profile.type || 'self')}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4 rtl:space-x-reverse">
                       <div className="text-right">
                          <div className="text-2xl font-black text-pink-600">{entry.result.label}</div>
                          <div className="text-[8px] font-black uppercase text-zinc-400 tracking-tighter">{t('recommendedSize')}</div>
                       </div>
                       <div className="w-10 h-10 rounded-full border-2 border-zinc-100 flex items-center justify-center text-[10px] font-black text-zinc-500">
                          {entry.result.confidence}%
                       </div>
                    </div>
                  </Card>
                ))}
             </div>
          </div>
        )}
      </div>
    </AppLayout>
  );
};