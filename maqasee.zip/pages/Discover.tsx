import React, { useEffect, useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { Card, Button, Loading } from '../components/UI';
import { AppLayout } from '../components/Layout';
import { auth } from '../firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { getUserProfile, getProfile, getAllRecommendations, getDiscoveryLinks } from '../services/firestore';
import { SEED_CHARTS, findBestSize } from '../services/sizeEngine';
import { UserProfile, Profile, Recommendation, DiscoveryLink } from '../types';
import { GoogleGenAI } from "@google/genai";
import { useNavigate } from 'react-router-dom';

export const Discover: React.FC = () => {
  const { t, language, isRTL } = useLanguage();
  const navigate = useNavigate();
  const [activeProfile, setActiveProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [personaLoading, setPersonaLoading] = useState(false);
  const [persona, setPersona] = useState({ title: '', advice: '' });
  const [platformMatches, setPlatformMatches] = useState<any[]>([]);
  const [discoveryLinks, setDiscoveryLinks] = useState<DiscoveryLink[]>([]);

  const aiIconUrl = "https://i.postimg.cc/Qt6h8Yt7/MAQ-(3).png";

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        const userData = await getUserProfile(user.uid);
        if (userData?.activeProfileId) {
          const [p, links] = await Promise.all([
            getProfile(user.uid, userData.activeProfileId),
            getDiscoveryLinks()
          ]);
          setActiveProfile(p);
          setDiscoveryLinks(links);
          if (p) {
            const history = await getAllRecommendations(user.uid, p.id);
            generatePlatformSummary(p);
            generateAIPersona(p, history);
          }
        }
      } else {
        navigate('/auth');
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, [navigate, language]);

  const generatePlatformSummary = (profile: Profile) => {
    const matches = SEED_CHARTS.filter(c => c.category === 'tops').map(chart => {
      const res = findBestSize(profile.measurements, chart, profile.fitPreference, profile.stretchTolerance);
      return {
        platform: chart.platform,
        size: res.label,
        confidence: res.confidence,
        category: chart.category
      };
    });
    setPlatformMatches(matches);
  };

  const generateAIPersona = async (profile: Profile, history: Recommendation[]) => {
    setPersonaLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const feedbackSummary = history.filter(h => h.feedback).map(h => `${h.platform}: ${h.recommendedSize} was ${h.feedback}`).join(', ');

      const systemInstruction = language === 'ar'
        ? "أنت خبير مظهر وأناقة كويتي. رد حصراً باللهجة الكويتية العامية. ابتكر مسمى 'شخصية أناقة' من 3 كلمات ونصيحة ملاءمة من جملة واحدة. التنسيق: العنوان | النصيحة"
        : "You are a style and fashion expert. Create a 3-word 'Style Persona' title and a 1-sentence fit advice in English. Format: Title | Advice";

      const prompt = `Stats: H:${profile.measurements.height_cm}cm, C:${profile.measurements.chest_cm}cm, W:${profile.measurements.waist_cm}cm. History: ${feedbackSummary || 'None'}.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: { systemInstruction, temperature: 0.7 }
      });

      const text = response.text || '';
      const parts = text.split('|');
      if (parts.length >= 2) {
        setPersona({ title: parts[0].trim(), advice: parts[1].trim() });
      } else {
        setPersona({ title: language === 'ar' ? 'أنيق بامتياز' : 'Modern Fit', advice: text.trim() });
      }
    } catch (err) {
      setPersona({ 
        title: language === 'ar' ? 'الباحث عن الأناقة' : 'Style Explorer', 
        advice: language === 'ar' ? 'قياساتك متوازنة بشكل رائع وتناسب القصات الكلاسيكية.' : 'Your measurements are perfectly balanced for classic cuts.' 
      });
    } finally {
      setPersonaLoading(false);
    }
  };

  /**
   * Color & Icon Mapping:
   * Swapped icons for 'shoes' and 'dresses' as per user request.
   */
  const categories = [
    { id: 'tops', icon: 'https://i.postimg.cc/GmjPmvF9/MAQ-(9).png', color: 'bg-[#F08A82]', textColor: 'text-zinc-900' },
    { id: 'bottoms', icon: 'https://i.postimg.cc/fW0x0Gcq/MAQ-(7).png', color: 'bg-[#89A7A1]', textColor: 'text-zinc-900' },
    { id: 'shoes', icon: 'https://i.postimg.cc/4NPnKP0g/MAQ-(5).png', color: 'bg-[#F1B95B]', textColor: 'text-zinc-900' }, // Now has Dress icon
    { id: 'dresses', icon: 'https://i.postimg.cc/zGpWr8Nf/MAQ-(4).png', color: 'bg-[#F6CDC4]', textColor: 'text-zinc-900' }, // Now has Shoe icon
    { id: 'abaya', icon: 'https://i.postimg.cc/t4mTkTpH/MAQ-(6).png', color: 'bg-[#F08A82]', textColor: 'text-zinc-900' },
    { id: 'dishdasha', icon: 'https://i.postimg.cc/BbsQbP5d/MAQ-(8).png', color: 'bg-[#89A7A1]', textColor: 'text-zinc-900' }
  ];

  const handleCategoryClick = (catId: string) => {
    const link = discoveryLinks.find(l => l.category === catId);
    if (link) {
      window.open(link.url, '_blank');
    } else {
      navigate('/app/size-finder');
    }
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-[#F7F1E5]">
      <Loading />
    </div>
  );

  return (
    <AppLayout>
      <div className="space-y-10 pb-12">
        <header className="px-2">
          <h1 className="text-3xl font-black text-black tracking-tight">{t('discoveryTitle')}</h1>
          <p className="text-zinc-600 text-[10px] font-black uppercase tracking-[0.2em] mt-1">{t('basedOnDna')}</p>
        </header>

        {/* Style Persona AI Card */}
        <div className="relative group">
           <div className="absolute -inset-0.5 bg-gradient-to-r from-[#F1B95B]/20 via-[#F08A82]/20 to-[#89A7A1]/20 rounded-[3rem] blur-xl opacity-50 group-hover:opacity-100 transition duration-1000"></div>
           <Card className="relative bg-white/60 backdrop-blur-2xl border border-white/80 p-8 space-y-8 overflow-hidden">
              <div className="flex items-center justify-between">
                 <div className="space-y-1">
                    <h3 className="text-[10px] font-black uppercase text-zinc-600 tracking-[0.25em]">{t('stylePersona')}</h3>
                    {personaLoading ? (
                      <div className="h-8 w-48 bg-zinc-200/40 rounded-lg animate-pulse" />
                    ) : (
                      <h2 className="text-2xl font-black text-zinc-900 leading-tight tracking-tight">{persona.title}</h2>
                    )}
                 </div>
                 <div className={`w-16 h-16 shrink-0 transition-all duration-700 ${personaLoading ? 'scale-90 opacity-40 rotate-12' : 'scale-100 opacity-100'}`}>
                   <img src={aiIconUrl} alt="Maqasee AI" className="w-full h-full object-contain drop-shadow-xl" />
                 </div>
              </div>

              <div className="bg-zinc-900/5 rounded-[2rem] p-6 border border-white/40 flex flex-col space-y-3">
                 <div className="flex justify-between items-center">
                    <div className="flex items-center space-x-2 rtl:space-x-reverse">
                       <span className="w-1.5 h-1.5 bg-[#F08A82] rounded-full animate-pulse"></span>
                       <h4 className="text-[9px] font-black uppercase text-zinc-600 tracking-widest">{t('styleAdvice')}</h4>
                    </div>
                    {!personaLoading && <div className="px-2.5 py-1 bg-white/80 text-zinc-900 text-[7px] font-black uppercase rounded-full shadow-sm border border-zinc-100/50">{t('aiLearning')}</div>}
                 </div>
                 {personaLoading ? (
                    <div className="space-y-3">
                       <div className="h-3 w-full bg-zinc-300/40 rounded-full animate-pulse" />
                       <div className="h-3 w-4/5 bg-zinc-300/40 rounded-full animate-pulse" />
                    </div>
                 ) : (
                    <p className="text-sm font-bold text-zinc-800 leading-relaxed italic">"{persona.advice}"</p>
                 )}
              </div>
           </Card>
        </div>

        {/* Categories Grid - Styled boxes matching reference */}
        <div className="space-y-4">
           <div className="flex justify-between items-center px-2">
              <h3 className="text-[10px] font-black uppercase tracking-[0.25em] text-zinc-600">{t('category')}</h3>
           </div>
           <div className="grid grid-cols-2 gap-5">
              {categories.map((cat) => {
                const customLink = discoveryLinks.find(l => l.category === cat.id);
                return (
                  <button 
                     key={cat.id} 
                     onClick={() => handleCategoryClick(cat.id)}
                     className={`flex flex-col items-center p-6 rounded-[3rem] shadow-[0_20px_40px_-15px_rgba(0,0,0,0.1)] hover:shadow-2xl hover:-translate-y-1 transition-all group active:scale-95 border border-white/20 ${cat.color}`}
                  >
                     {/* Icon Container - White rounded box matching reference */}
                     <div className="w-24 h-24 bg-white rounded-[2rem] flex items-center justify-center mb-6 shadow-sm group-hover:scale-105 transition-transform duration-500 overflow-hidden p-3">
                        <img 
                          src={cat.icon} 
                          alt={cat.id} 
                          className="w-full h-full object-contain" 
                        />
                     </div>
                     <div className="space-y-1.5 text-center">
                        <h4 className={`text-xs font-black uppercase tracking-[0.15em] ${cat.textColor}`}>{t(cat.id as any)}</h4>
                        <p className={`text-[8px] font-black uppercase tracking-widest ${cat.textColor} opacity-50`}>
                           {customLink ? (customLink.label || t('shopNow')) : t('shopNow')}
                        </p>
                     </div>
                  </button>
                );
              })}
           </div>
        </div>

        {/* Best Fits Section */}
        <div className="space-y-6 pt-4">
          <div className="px-2">
            <h3 className="text-[10px] font-black uppercase tracking-[0.25em] text-zinc-600">{t('yourBestFits')}</h3>
          </div>
          <div className="flex overflow-x-auto hide-scrollbar space-x-6 rtl:space-x-reverse py-4 px-2">
             {platformMatches.length > 0 ? platformMatches.map((match, idx) => (
               <Card key={idx} className="min-w-[180px] flex flex-col p-6 space-y-6 bg-white border-zinc-100/40 hover:border-zinc-900/10 transition-all cursor-pointer group shadow-xl shadow-zinc-900/[0.01]">
                  <div className="flex justify-between items-center">
                    <span className="text-[9px] font-black uppercase tracking-widest text-zinc-500 group-hover:text-zinc-900 transition-colors">{match.platform}</span>
                    <div className="px-2 py-0.5 bg-zinc-50 text-zinc-600 group-hover:bg-[#F08A82] group-hover:text-white rounded-full text-[7px] font-black uppercase transition-all">{t(match.category as any)}</div>
                  </div>
                  <div className="flex flex-col items-center py-2">
                    <span className="text-7xl font-black text-zinc-900 tracking-tighter group-hover:scale-110 transition-transform duration-500">{match.size}</span>
                    <span className="text-[8px] font-black uppercase text-zinc-500 mt-3 tracking-widest">{t('recommendedSize')}</span>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                       <span className="text-[8px] font-black uppercase text-zinc-600">{t('confidence')}</span>
                       <span className="text-[9px] font-black text-zinc-900">{match.confidence}%</span>
                    </div>
                    <div className="h-1 bg-zinc-50 rounded-full overflow-hidden">
                       <div className="h-full bg-[#F08A82] transition-all duration-1000 ease-out" style={{ width: `${match.confidence}%` }}></div>
                    </div>
                  </div>
               </Card>
             )) : (
               [1,2,3].map(i => (
                 <div key={i} className="min-w-[180px] h-64 bg-white rounded-[2.5rem] animate-pulse" />
               ))
             )}
          </div>
        </div>
      </div>
    </AppLayout>
  );
};