import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { Card, Button, Input } from '../components/UI';
import { useNavigate } from 'react-router-dom';
import { auth } from '../firebase';
import { signInWithEmailAndPassword, createUserWithEmailAndPassword } from 'firebase/auth';
import { saveUserProfile } from '../services/firestore';

export const Auth: React.FC = () => {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Unified logo for all languages
  const logoUrl = "https://i.postimg.cc/tCD6Wpcg/Chat-GPT-Image-Jan-30-2026-02-19-49-PM.png";

  const handleAuth = async () => {
    setLoading(true);
    setError('');
    try {
      if (isLogin) {
        await signInWithEmailAndPassword(auth, email, password);
      } else {
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        // Initialize profile for new user
        await saveUserProfile(userCredential.user.uid, { name: email.split('@')[0] });
      }
      navigate('/app');
    } catch (err: any) {
      setError(t('errorAuth'));
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F4F2F7] flex flex-col justify-center px-8 relative overflow-hidden">
      {/* Visual background element */}
      <div className="absolute top-[-5%] left-[-10%] w-64 h-64 bg-[#FDF2F8] organic-shape opacity-40"></div>
      <div className="absolute bottom-[-5%] right-[-5%] w-80 h-80 bg-[#EFF6FF] organic-shape opacity-30"></div>
      
      <div className="max-w-md w-full mx-auto space-y-8 relative z-10">
        <div className="flex flex-col items-center space-y-6 px-2">
          {/* Logo Section */}
          <div className="w-24 h-24 bg-white rounded-[2rem] flex items-center justify-center shadow-soft border border-white overflow-hidden p-1">
            <img src={logoUrl} alt="Maqasee" className="w-full h-full object-contain" />
          </div>

          <div className="text-center space-y-2">
            <h1 className="text-4xl font-black text-black tracking-tight">{isLogin ? t('login') : t('signup')}</h1>
            <p className="text-sm text-zinc-500 font-medium max-w-[280px] mx-auto">
              {isLogin ? t('loginSubtitle') : t('signupSubtitle')}
            </p>
          </div>
        </div>

        <Card className="space-y-4 shadow-xl shadow-black/5">
          {error && (
            <div className="bg-red-50 text-red-500 text-[10px] font-bold p-3 rounded-xl border border-red-100 animate-in fade-in zoom-in duration-200">
              {error}
            </div>
          )}
          <Input 
            label={t('email')} 
            placeholder="noura@example.com" 
            value={email} 
            onChange={(e) => setEmail(e.target.value)} 
          />
          <Input 
            label={t('password')} 
            type="password" 
            placeholder="••••••••" 
            value={password} 
            onChange={(e) => setPassword(e.target.value)} 
          />
          <div className="pt-4">
            <Button onClick={handleAuth} fullWidth className="py-4 text-sm font-black uppercase tracking-widest shadow-lg shadow-black/10">
              {loading ? t('loading') : (isLogin ? t('login') : t('signup'))}
            </Button>
          </div>
        </Card>

        <p className="text-center text-[10px] text-zinc-400 font-black uppercase tracking-[0.2em]">
          {isLogin ? t('noAccount') : t('hasAccount')}{" "}
          <button 
            onClick={() => setIsLogin(!isLogin)} 
            className="text-black underline cursor-pointer decoration-2 underline-offset-4"
          >
            {isLogin ? t('signup') : t('login')}
          </button>
        </p>
      </div>
    </div>
  );
};
