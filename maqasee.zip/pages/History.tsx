import React, { useEffect, useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { Card, useToast, Loading } from '../components/UI';
import { AppLayout } from '../components/Layout';
import { useNavigate } from 'react-router-dom';
import { auth } from '../firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { getAllRecommendations, getUserProfile, updateRecommendationFeedback } from '../services/firestore';
import { Recommendation, FitFeedback } from '../types';

export const History: React.FC = () => {
  const { t, isRTL } = useLanguage();
  const { showToast } = useToast();
  const navigate = useNavigate();
  const [history, setHistory] = useState<Recommendation[]>([]);
  const [loading, setLoading] = useState(true);
  const [uid, setUid] = useState<string | null>(null);
  const [expandedId, setExpandedId] = useState<string | null>(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        setUid(user.uid);
        const userData = await getUserProfile(user.uid);
        if (userData?.activeProfileId) {
          const data = await getAllRecommendations(user.uid, userData.activeProfileId);
          setHistory(data);
        }
      } else {
        navigate('/auth');
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, [navigate]);

  const handleFeedback = async (recId: string, feedback: FitFeedback) => {
    if (!uid) return;
    
    // Immediate local state update for snappy UI
    setHistory(prev => {
      const newHistory = [...prev];
      const index = newHistory.findIndex(r => r.id === recId);
      if (index !== -1) {
        newHistory[index] = { ...newHistory[index], feedback };
      }
      return newHistory;
    });

    try {
      await updateRecommendationFeedback(uid, recId, feedback);
      showToast(t('feedbackSaved'));
    } catch (err) {
      console.error(err);
    }
    setExpandedId(null);
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-zinc-50">
      <Loading />
    </div>
  );

  return (
    <AppLayout>
      <div className="space-y-8 pb-12">
        <header className="flex items-center space-x-4 rtl:space-x-reverse">
          <button onClick={() => navigate('/app')} className="p-2 bg-zinc-100 rounded-full text-black active:scale-90 transition-transform">
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={isRTL ? "M9 5l7 7-7 7" : "M15 19l-7-7 7-7"} />
            </svg>
          </button>
          <h1 className="text-2xl font-bold text-black">{t('history')}</h1>
        </header>

        {history.length === 0 ? (
          <div className="py-20 text-center space-y-4">
             <div className="w-20 h-20 bg-zinc-50 rounded-full mx-auto flex items-center justify-center"><svg className="w-10 h-10 text-zinc-200" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg></div>
             <p className="text-zinc-400 font-medium">{t('noHistory')}</p>
          </div>
        ) : (
          <div className="space-y-4">
            {history.map((rec) => {
              const isExpanded = expandedId === rec.id;
              const hasFeedback = !!rec.feedback;
              
              return (
                <div key={`${rec.id}-${rec.feedback}`} className="space-y-2">
                  <Card 
                    className={`flex justify-between items-center p-5 border transition-all cursor-pointer ${isExpanded ? 'border-zinc-900 bg-zinc-50' : 'border-zinc-50 hover:border-zinc-200'} ${hasFeedback ? 'bg-green-50/20' : ''}`}
                    onClick={() => setExpandedId(isExpanded ? null : rec.id)}
                  >
                    <div className="flex items-center space-x-4 rtl:space-x-reverse">
                      <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shadow-inner transition-colors ${hasFeedback ? 'bg-green-100' : 'bg-zinc-50'}`}>
                        {hasFeedback ? (
                          <span className="text-xl animate-in zoom-in duration-300">✅</span>
                        ) : (
                          <span className="text-lg font-black text-zinc-400 uppercase">{rec.platform.charAt(0)}</span>
                        )}
                      </div>
                      <div className="space-y-0.5">
                        <div className="flex items-center space-x-2 rtl:space-x-reverse">
                          <h4 className="font-bold text-lg capitalize">{rec.platform} - <span className="text-pink-500">{rec.recommendedSize}</span></h4>
                          {rec.feedback && <span className="px-2 py-0.5 bg-green-100 text-green-700 rounded-full text-[8px] font-black uppercase tracking-tighter">{t(rec.feedback)}</span>}
                        </div>
                        <p className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider">{new Date(rec.timestamp).toLocaleDateString()} • {t(rec.category as any)}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-lg font-black text-zinc-900">{rec.confidence}%</div>
                      <div className="text-[8px] font-black uppercase text-zinc-300 tracking-tighter">{t('confidence')}</div>
                    </div>
                  </Card>
                  
                  {isExpanded && (
                    <div className="animate-in fade-in slide-in-from-top-2 duration-300">
                      <div className="bg-white rounded-[2rem] p-6 border border-zinc-100 shadow-sm space-y-4">
                        <h5 className="text-center text-xs font-bold text-zinc-500 uppercase tracking-[0.2em]">{t('howWasFit')}</h5>
                        <div className="grid grid-cols-3 gap-3">
                           {(['tight', 'perfect', 'loose'] as FitFeedback[]).map((f) => (
                             <button
                               key={f}
                               onClick={(e) => { e.stopPropagation(); handleFeedback(rec.id, f); }}
                               className={`py-3 rounded-2xl text-[9px] font-black uppercase tracking-tighter transition-all ${rec.feedback === f ? 'bg-black text-white shadow-md' : 'bg-zinc-50 text-zinc-400 border border-zinc-100 hover:bg-zinc-100'}`}
                             >
                               {t(`too${f.charAt(0).toUpperCase()}${f.slice(1)}` as any) || t(f)}
                             </button>
                           ))}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </AppLayout>
  );
};