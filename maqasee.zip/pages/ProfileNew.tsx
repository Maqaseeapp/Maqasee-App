import React, { useState, useEffect } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { Card, Button, Input, useToast } from '../components/UI';
import { AppLayout } from '../components/Layout';
import { useNavigate, useLocation } from 'react-router-dom';
import { auth } from '../firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { getUserProfile, updateProfileMeasurements, createProfile, getProfile } from '../services/firestore';
import { Measurements, Relationship, Gender } from '../types';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { GoogleGenAI } from "@google/genai";

const measurementSchema = z.object({
  profileName: z.string().min(2).max(20),
  relationship: z.enum(['self', 'friend', 'family']),
  gender: z.enum(['men', 'women']),
  height_cm: z.number().min(50).max(250).optional(),
  weight_kg: z.number().min(20).max(300).optional(),
  neck_cm: z.number().min(20).max(70).optional(),
  chest_cm: z.number().min(50).max(200).optional(),
  waist_cm: z.number().min(40).max(200).optional(),
  hips_cm: z.number().min(50).max(200).optional(),
  shoulder_cm: z.number().min(20).max(100).optional(),
  sleeve_cm: z.number().min(20).max(120).optional(),
  inseam_cm: z.number().min(20).max(150).optional(),
  thigh_cm: z.number().min(20).max(120).optional(),
  foot_cm: z.number().min(10).max(50).optional(),
});

type MeasurementFormData = z.infer<typeof measurementSchema>;

export const ProfileNew: React.FC = () => {
  const { t, isRTL, language } = useLanguage();
  const { showToast } = useToast();
  const navigate = useNavigate();
  const location = useLocation();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [uid, setUid] = useState<string | null>(null);
  const [aiRealityCheck, setAiRealityCheck] = useState<string>('');

  const aiIconUrl = "https://i.postimg.cc/Qt6h8Yt7/MAQ-(3).png";
  
  const { register, handleSubmit, setValue, watch, formState: { errors } } = useForm<MeasurementFormData>({
    resolver: zodResolver(measurementSchema),
    defaultValues: { profileName: '', relationship: 'self', gender: 'women' }
  });

  const totalSteps = 4;
  const relationship = watch('relationship');
  const gender = watch('gender');

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        setUid(user.uid);
        
        const scanData = location.state?.scannedMeasurements;
        if (scanData) {
          setTimeout(() => {
            Object.entries(scanData).forEach(([key, val]) => {
              if (val !== undefined && val !== null) {
                if (key === 'gender') {
                  const detectedGender = val === 'men' || val === 'women' ? val : 'women';
                  setValue('gender', detectedGender);
                } else {
                  setValue(key as any, Number(val));
                }
              }
            });
            showToast(t('measurementsVerified'));
          }, 100);
        } else {
          const userData = await getUserProfile(user.uid);
          if (userData?.activeProfileId) {
            const profileData = await getProfile(user.uid, userData.activeProfileId);
            if (profileData) {
              setValue('profileName', profileData.name);
              setValue('relationship', profileData.type || 'self');
              setValue('gender', profileData.gender || 'women');
              Object.entries(profileData.measurements).forEach(([key, val]) => {
                setValue(key as any, val);
              });
            }
          }
        }
      } else {
        navigate('/auth');
      }
    });
    return () => unsubscribe();
  }, [navigate, setValue, location.state]);

  useEffect(() => {
    if (step === 4) {
      performAiRealityCheck();
    }
  }, [language]);

  const steps = [
    { title: t('whosThisFor'), fields: ["profileName", "relationship", "gender", "height_cm", "weight_kg"] },
    { title: t('torso'), fields: ["neck_cm", "chest_cm", "waist_cm", "shoulder_cm"] },
    { title: t('lowerBody'), fields: ["hips_cm", "inseam_cm", "thigh_cm", "foot_cm"] },
    { title: t('realityCheck'), fields: [] },
  ];

  const performAiRealityCheck = async () => {
    const vals = watch();
    setAiRealityCheck('');
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      const systemInstruction = language === 'ar'
        ? "أنت خبير قياسات وتصميم ملابس. رد حصراً باللهجة الكويتية العامية البسيطة. لا تستخدم الفصحى نهائياً ولا تستخدم الإنجليزية. ردك يجب أن يكون قصيراً جداً (جملة واحدة فقط)."
        : "You are a professional tailoring expert. Provide a very brief, 1-sentence reality check on measurements in English.";

      const prompt = `Measurements: Height ${vals.height_cm}cm, Weight ${vals.weight_kg}kg, Waist ${vals.waist_cm}cm, Chest ${vals.chest_cm}cm. Are these realistic?`;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: {
          systemInstruction,
          temperature: 0.7,
        }
      });
      setAiRealityCheck(response.text || '');
    } catch (err) {
      console.error(err);
      setAiRealityCheck(t('measurementsVerified'));
    }
  };

  const onSubmit = async (data: MeasurementFormData) => {
    if (!uid) return;
    setLoading(true);
    try {
      const profileId = data.profileName.toLowerCase().replace(/\s+/g, '-');
      await createProfile(uid, profileId, data.profileName, data.gender);
      
      const { profileName, relationship, gender, ...measurements } = data;
      await updateProfileMeasurements(uid, profileId, measurements);
      showToast(t('successSave'));
      navigate('/app');
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleNext = async () => {
    if (step === 3) {
      setStep(4);
      await performAiRealityCheck();
    } else if (step < totalSteps) {
      setStep(step + 1);
    } else {
      handleSubmit(onSubmit)();
    }
  };

  const currentStepData = steps[step-1];

  return (
    <AppLayout showNav={false}>
      <div className="space-y-8 pb-12">
        <header className="flex items-center space-x-4 rtl:space-x-reverse">
          <button onClick={() => step > 1 ? setStep(step-1) : navigate('/app')} className="p-2 bg-zinc-100 rounded-full text-black active:scale-90 transition-transform">
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={isRTL ? "M9 5l7 7-7 7" : "M15 19l-7-7 7-7"} /></svg>
          </button>
          <div className="flex-1">
            <h1 className="text-xl font-black text-black">{t('newMeasurement')}</h1>
            <p className="text-xs text-zinc-400 font-black uppercase tracking-[0.2em]">{t('step')} {step} / {totalSteps}</p>
          </div>
        </header>

        <div className="w-full h-1 bg-zinc-100 rounded-full overflow-hidden">
          <div className="h-full bg-zinc-900 transition-all duration-500" style={{ width: `${(step/totalSteps) * 100}%` }} />
        </div>

        <Card className="space-y-6">
          <h2 className="text-lg font-black text-zinc-800">{currentStepData.title}</h2>
          
          {step === 4 ? (
            <div className="space-y-4 py-4">
               <div className="w-16 h-16 mx-auto mb-4">
                 <img src={aiIconUrl} alt="Maqasee AI" className="w-full h-full object-contain" />
               </div>
               <p className="text-sm text-zinc-600 leading-relaxed text-center font-bold">
                 {aiRealityCheck || t('loading')}
               </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-4">
              {currentStepData.fields.map((field) => {
                if (field === 'relationship') {
                  return (
                    <div key={field} className="space-y-2">
                       <label className="text-xs font-bold text-zinc-500 px-1 uppercase tracking-wider">{t('relationship')}</label>
                       <div className="grid grid-cols-3 gap-2">
                          {(['self', 'friend', 'family'] as Relationship[]).map(r => (
                            <button
                              key={r}
                              type="button"
                              onClick={() => setValue('relationship', r)}
                              className={`py-4 rounded-2xl text-[10px] font-black uppercase transition-all shadow-sm ${relationship === r ? 'bg-[#F1B95B] text-white shadow-md' : 'bg-zinc-50 text-zinc-400 border border-zinc-100'}`}
                            >
                              {t(r as any)}
                            </button>
                          ))}
                       </div>
                    </div>
                  );
                }
                if (field === 'gender') {
                  return (
                    <div key={field} className="space-y-2">
                       <label className="text-xs font-bold text-zinc-500 px-1 uppercase tracking-wider">{t('gender')}</label>
                       <div className="grid grid-cols-2 gap-2">
                          {(['men', 'women'] as Gender[]).map(g => (
                            <button
                              key={g}
                              type="button"
                              onClick={() => setValue('gender', g)}
                              className={`py-4 rounded-2xl text-[10px] font-black uppercase transition-all shadow-sm ${gender === g ? 'bg-[#F1B95B] text-white shadow-md' : 'bg-zinc-50 text-zinc-400 border border-zinc-100'}`}
                            >
                              {t(g as any)}
                            </button>
                          ))}
                       </div>
                    </div>
                  );
                }
                return (
                  <div key={field} className="space-y-1">
                      <Input 
                        label={t(field.split('_')[0] as any)} 
                        type={field === 'profileName' ? 'text' : 'number'}
                        placeholder={field === 'profileName' ? 'e.g. Myself' : `0 ${field.includes('kg') ? t('weightUnit') : t('metricUnit')}`}
                        {...register(field as any, { valueAsNumber: field !== 'profileName' && field !== 'relationship' && field !== 'gender' })}
                      />
                      {errors[field as keyof MeasurementFormData] && (
                        <p className="text-[10px] text-red-500 font-bold px-1">{t('outOfRange')}</p>
                      )}
                  </div>
                );
              })}
            </div>
          )}
        </Card>

        <div className="flex flex-col space-y-3">
          <Button onClick={handleNext} fullWidth disabled={loading} className="py-5 text-sm font-black uppercase tracking-widest shadow-xl shadow-black/5">
            {loading ? t('loading') : (step === totalSteps ? t('finish') : t('next'))}
          </Button>
          {step > 1 && (
            <Button variant="ghost" onClick={() => setStep(step-1)} fullWidth className="font-black text-zinc-400 text-xs uppercase tracking-widest">
              {t('back')}
            </Button>
          )}
        </div>
      </div>
    </AppLayout>
  );
};