import React, { useEffect, useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { Card, Button, Loading } from '../components/UI';
import { AppLayout } from '../components/Layout';
import { useNavigate } from 'react-router-dom';
import { auth } from '../firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { getProfiles } from '../services/firestore';
import { Profile } from '../types';
import { COLORS } from '../constants';

export const SizeFriends: React.FC = () => {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);

  // Fixed color properties to use existing COLORS (sage and salmon instead of blue and green)
  const getAvatarColor = (name: string) => {
    const hash = name.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    const colors = [COLORS.yellow, COLORS.pink, COLORS.sage, COLORS.salmon];
    return colors[hash % colors.length];
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      if (fbUser) {
        const allProfiles = await getProfiles(fbUser.uid);
        setProfiles(allProfiles);
      } else {
        navigate('/auth');
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, [navigate]);

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-zinc-50">
      <Loading />
    </div>
  );

  return (
    <AppLayout>
      <div className="space-y-8 pb-12">
        <header>
          <h1 className="text-2xl font-bold text-black">{t('sizeFriends')}</h1>
          <p className="text-zinc-400 text-sm font-medium">{t('manageFriends')}</p>
        </header>

        <div className="grid grid-cols-1 gap-4">
          {profiles.map(p => (
            <Card key={p.id} className="flex items-center justify-between p-5 border border-zinc-50 hover:border-zinc-200 transition-colors" bgColor="bg-white">
              <div className="flex items-center space-x-4 rtl:space-x-reverse">
                <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-lg font-black shadow-inner" style={{ backgroundColor: getAvatarColor(p.name) }}>
                   {p.name.charAt(0).toUpperCase()}
                </div>
                <div>
                  <h4 className="font-black text-sm text-zinc-900">{p.name}</h4>
                  <p className="text-[9px] font-bold text-zinc-400 uppercase tracking-widest">{t(p.type || 'self')}</p>
                </div>
              </div>
              <Button variant="ghost" onClick={() => navigate('/app/profile')} className="!text-[10px] !px-4">
                {t('profile')}
              </Button>
            </Card>
          ))}
          
          <Button variant="secondary" onClick={() => navigate('/app/profile/new')} fullWidth className="py-4 border-dashed">
            {t('addProfile')}
          </Button>
        </div>

        <Card className="bg-blue-50/50 border border-blue-100 p-6 flex items-start space-x-4 rtl:space-x-reverse">
           <div className="text-2xl">🎁</div>
           <div className="space-y-1">
              <h4 className="text-[10px] font-black uppercase text-blue-600 tracking-widest">{t('giftRecommendations')}</h4>
              <p className="text-xs font-medium text-zinc-600 leading-relaxed">
                {t('friendsAdvice')}
              </p>
           </div>
        </Card>
      </div>
    </AppLayout>
  );
};