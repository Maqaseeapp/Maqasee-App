import React, { useEffect, useRef, useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { Button, Card, Loading, useToast } from '../components/UI';
import { AppLayout } from '../components/Layout';
import { useNavigate } from 'react-router-dom';
import { GoogleGenAI, Type } from "@google/genai";
import { auth } from '../firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { getUserProfile, getProfile, saveSnapShopResult } from '../services/firestore';
import { Profile, ProductResult } from '../types';
import { ICONS } from '../constants';

export const SnapShop: React.FC = () => {
  const { t, isRTL, language } = useLanguage();
  const { showToast } = useToast();
  const navigate = useNavigate();
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [scanning, setScanning] = useState(false);
  const [status, setStatus] = useState('');
  const [results, setResults] = useState<ProductResult[]>([]);
  const [activeProfile, setActiveProfile] = useState<Profile | null>(null);
  const [needsKey, setNeedsKey] = useState(false);
  const [uid, setUid] = useState<string | null>(null);

  const aiIconUrl = "https://i.postimg.cc/Qt6h8Yt7/MAQ-(3).png";

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        setUid(user.uid);
        const userData = await getUserProfile(user.uid);
        if (userData?.activeProfileId) {
          const p = await getProfile(user.uid, userData.activeProfileId);
          setActiveProfile(p);
        }
        
        // Safety check for AI Studio global
        const hasKey = (window as any).aistudio ? await (window as any).aistudio.hasSelectedApiKey() : true;
        if (!hasKey) {
            setNeedsKey(true);
        }
      } else {
        navigate('/auth');
      }
    });

    async function startCamera() {
      try {
        const s = await navigator.mediaDevices.getUserMedia({ 
          video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } } 
        });
        setStream(s);
        if (videoRef.current) videoRef.current.srcObject = s;
      } catch (err) {
        console.error("Camera access error:", err);
      }
    }

    startCamera();
    return () => {
      unsubscribe();
      stream?.getTracks().forEach(track => track.stop());
    };
  }, []);

  const handleSelectKey = async () => {
    if ((window as any).aistudio) {
        await (window as any).aistudio.openSelectKey();
        setNeedsKey(false);
    }
  };

  const handleSnap = async () => {
    if (!videoRef.current || !canvasRef.current || !activeProfile || !uid) return;
    
    setScanning(true);
    setStatus(t('analyzingImage'));

    try {
      const canvas = canvasRef.current;
      const video = videoRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      
      const base64Image = canvas.toDataURL('image/jpeg', 0.8).split(',')[1];

      setStatus(t('searchingWeb'));
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      const m = activeProfile.measurements;
      const measurementContext = `Height: ${m.height_cm}cm, Chest: ${m.chest_cm}cm, Waist: ${m.waist_cm}cm, Hips: ${m.hips_cm}cm, Foot: ${m.foot_cm}cm. Gender: ${activeProfile.gender || 'unisex'}. Fit: ${activeProfile.fitPreference}.`;

      const prompt = `Identify the clothing item in this image. Search the internet for this exact item or highly similar alternatives (Tops, Bottoms, Footwear, Dresses, Abaya, Dishdasha). 
      IMPORTANT: Compare each product's sizing standards to these measurements: ${measurementContext}.
      Recommend the specific size (e.g., M, 38, 56) that fits best based on your analysis of typical brand charts.
      Return a JSON array of up to 5 products. Each object MUST HAVE:
      "name": product title,
      "price": approximate price,
      "url": direct purchase or info link,
      "store": platform name,
      "recommendedSize": the specific size for the user,
      "matchScore": percentage fit confidence (0-100).`;

      const response = await ai.models.generateContent({
        model: 'gemini-3-pro-image-preview',
        contents: [
          {
            parts: [
              { text: prompt },
              { inlineData: { mimeType: 'image/jpeg', data: base64Image } }
            ]
          }
        ],
        config: {
          tools: [{ googleSearch: {} }],
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                price: { type: Type.STRING },
                url: { type: Type.STRING },
                store: { type: Type.STRING },
                recommendedSize: { type: Type.STRING },
                matchScore: { type: Type.NUMBER }
              },
              required: ["name", "price", "url", "store", "recommendedSize", "matchScore"]
            }
          }
        }
      });

      // Handle potential extra text from grounding results before parsing JSON
      let rawText = response.text || '[]';
      // Basic cleanup in case model returns markdown
      if (rawText.includes('```json')) {
          rawText = rawText.split('```json')[1].split('```')[0].trim();
      } else if (rawText.includes('```')) {
          rawText = rawText.split('```')[1].split('```')[0].trim();
      }

      const parsedResults: ProductResult[] = JSON.parse(rawText);
      setResults(parsedResults);
      
      if (parsedResults.length > 0) {
          await saveSnapShopResult(uid, parsedResults);
      }

      setStatus('');
      if (parsedResults.length === 0) {
        showToast(t('noProductsFound'));
      }
    } catch (err: any) {
      console.error("SnapShop failed:", err);
      if (err.message?.includes("Requested entity was not found")) {
        setNeedsKey(true);
        showToast("Session expired. Please re-enable AI Shopping.");
      } else {
        showToast("Search failed. Try again.");
      }
    } finally {
      setScanning(false);
    }
  };

  return (
    <AppLayout showNav={false}>
      <div className="space-y-6 pb-12 flex flex-col h-full">
        <header className="flex items-center justify-between px-2">
          <div className="flex items-center space-x-4 rtl:space-x-reverse">
            <button onClick={() => navigate('/app')} className="p-2 bg-zinc-100 rounded-full text-black border border-zinc-200 active:scale-90 transition-transform">
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={isRTL ? "M9 5l7 7-7 7" : "M15 19l-7-7 7-7"} />
              </svg>
            </button>
            <h1 className="text-xl font-black text-black">{t('snapShop')}</h1>
          </div>
          {results.length > 0 && (
              <button onClick={() => {setResults([]); setStatus('');}} className="text-[10px] font-black uppercase text-zinc-400 tracking-widest underline decoration-2">{t('back')}</button>
          )}
        </header>

        {needsKey && results.length === 0 && (
            <Card className="bg-[#F1B95B]/10 border-[#F1B95B]/20 p-8 flex flex-col items-center text-center space-y-6 animate-in zoom-in duration-500">
                <div className="w-20 h-20 bg-white rounded-[2.5rem] flex items-center justify-center shadow-soft">
                    {ICONS.snapshop("w-10 h-10 text-[#F1B95B]")}
                </div>
                <div className="space-y-2">
                    <h2 className="text-lg font-black text-zinc-900">{t('selectKey')}</h2>
                    <p className="text-xs text-zinc-500 font-medium leading-relaxed max-w-[240px]">
                        {t('billingRequired')}
                    </p>
                </div>
                <div className="flex flex-col w-full space-y-3">
                    <Button onClick={handleSelectKey} fullWidth>{t('getStarted')}</Button>
                    <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" className="text-[9px] font-black uppercase text-zinc-400 tracking-widest hover:text-zinc-600 transition-colors">
                        {t('viewBilling')}
                    </a>
                </div>
            </Card>
        )}

        {results.length === 0 && !needsKey && (
          <div className="relative flex-1 bg-black rounded-[3rem] overflow-hidden shadow-2xl min-h-[450px]">
             <video ref={videoRef} autoPlay playsInline muted className="absolute inset-0 w-full h-full object-cover" />
             <canvas ref={canvasRef} className="hidden" />

             {/* Viewfinder Overlay */}
             <div className="absolute inset-0 flex flex-col items-center justify-center p-12 pointer-events-none">
                <div className="w-full h-full border-2 border-dashed border-white/20 rounded-[2.5rem] relative">
                    <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-[#F1B95B]/30 shadow-[0_0_15px_rgba(241,185,91,0.5)] animate-pulse" />
                    <div className="absolute left-1/2 top-0 bottom-0 w-0.5 bg-[#F1B95B]/30 shadow-[0_0_15px_rgba(241,185,91,0.5)] animate-pulse" />
                </div>
             </div>

             {scanning && (
               <div className="absolute inset-0 bg-black/70 backdrop-blur-md flex flex-col items-center justify-center space-y-6 z-50">
                  <div className="w-20 h-20 animate-bounce">
                     <img src={aiIconUrl} alt="Maqasee AI" className="w-full h-full object-contain" />
                  </div>
                  <div className="flex flex-col items-center space-y-2 px-12 text-center">
                     <div className="w-48 h-1.5 bg-white/20 rounded-full overflow-hidden">
                        <div className="h-full bg-[#F1B95B] animate-[loading_2s_ease-in-out_infinite]" style={{width: '30%'}}></div>
                     </div>
                     <span className="text-white font-black uppercase tracking-[0.2em] text-[10px]">{status}</span>
                  </div>
               </div>
             )}

             {!scanning && (
               <div className="absolute bottom-8 left-0 right-0 flex justify-center px-8">
                  <div className="bg-black/40 backdrop-blur-xl border border-white/10 p-4 rounded-3xl text-center">
                     <p className="text-white/90 text-[10px] font-black uppercase tracking-widest leading-relaxed">
                       {t('snapHelper')}
                     </p>
                  </div>
               </div>
             )}
          </div>
        )}

        {results.length === 0 && !needsKey && (
          <Button onClick={handleSnap} fullWidth className="py-6 border-none shadow-xl shadow-[#F1B95B]/10 active:scale-95" disabled={scanning}>
            {scanning ? t('loading') : t('snapProduct')}
          </Button>
        )}

        {results.length > 0 && (
          <div className="space-y-6 animate-in slide-in-from-bottom-6 duration-700">
             <div className="px-2 flex items-center justify-between">
                <div>
                   <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-zinc-500">{t('yourBestFits')}</h3>
                   <p className="text-sm font-black text-black">{isRTL ? 'تم العثور على ' + results.length + ' نتائج' : 'Found ' + results.length + ' Matches'}</p>
                </div>
                <div className="px-3 py-1.5 bg-green-100 text-green-700 rounded-full text-[8px] font-black uppercase tracking-widest">{t('verifiedFit')}</div>
             </div>

             <div className="grid grid-cols-1 gap-4">
                {results.map((product, idx) => (
                  <Card key={idx} className="flex flex-col p-6 space-y-4 bg-white border-zinc-100 shadow-xl shadow-zinc-900/[0.02]" bgColor="bg-white">
                     <div className="flex justify-between items-start">
                        <div className="space-y-1">
                           <h4 className="font-black text-sm text-zinc-900 line-clamp-1">{product.name}</h4>
                           <p className="text-[9px] font-black uppercase text-zinc-400 tracking-widest">{product.store} • {product.price}</p>
                        </div>
                        <div className="text-right">
                           <span className="text-2xl font-black text-[#F1B95B]">{product.recommendedSize}</span>
                           <p className="text-[7px] font-black uppercase text-zinc-400 tracking-tighter">{t('recommendedSize')}</p>
                        </div>
                     </div>

                     <div className="space-y-3 bg-zinc-50 rounded-2xl p-4 border border-zinc-100">
                        <div className="flex justify-between items-center">
                           <span className="text-[8px] font-black uppercase text-zinc-500">{t('fitScore')}</span>
                           <span className="text-[10px] font-black text-zinc-900">{product.matchScore}%</span>
                        </div>
                        <div className="h-1.5 bg-white rounded-full overflow-hidden">
                           <div className="h-full bg-green-400 transition-all duration-1000 ease-out" style={{ width: `${product.matchScore}%` }}></div>
                        </div>
                     </div>

                     <Button onClick={() => window.open(product.url, '_blank')} fullWidth className="!py-3 shadow-none border-zinc-900/5">
                        {t('shopNow')}
                     </Button>
                  </Card>
                ))}
             </div>
          </div>
        )}
      </div>
      <style>{`
        @keyframes loading {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(250%); }
        }
      `}</style>
    </AppLayout>
  );
};