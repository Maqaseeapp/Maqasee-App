import React, { useEffect, useRef, useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { Button } from '../components/UI';
import { AppLayout } from '../components/Layout';
import { useNavigate } from 'react-router-dom';
import { GoogleGenAI, Type } from "@google/genai";

export const Scan: React.FC = () => {
  const { t, isRTL, language } = useLanguage();
  const navigate = useNavigate();
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [scanning, setScanning] = useState(false);
  const [status, setStatus] = useState('');

  const aiIconUrl = "https://i.postimg.cc/Qt6h8Yt7/MAQ-(3).png";

  useEffect(() => {
    async function startCamera() {
      try {
        const s = await navigator.mediaDevices.getUserMedia({ 
          video: { facingMode: 'user', width: { ideal: 1280 }, height: { ideal: 720 } } 
        });
        setStream(s);
        if (videoRef.current) videoRef.current.srcObject = s;
      } catch (err) {
        console.error("Camera access error:", err);
      }
    }
    startCamera();
    return () => {
      stream?.getTracks().forEach(track => track.stop());
    };
  }, []);

  const handleScan = async () => {
    if (!videoRef.current || !canvasRef.current) return;
    
    setScanning(true);
    setStatus(t('scanning'));

    try {
      // 1. Capture the frame
      const canvas = canvasRef.current;
      const video = videoRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      }
      
      const base64Image = canvas.toDataURL('image/jpeg', 0.8).split(',')[1];

      // 2. Send to Gemini for Analysis using strict Response Schema
      setStatus(t('aiLearning'));
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      const prompt = `Analyze this person's body proportions and physical characteristics for a fashion app. 
      Identify if the person is 'men' or 'women'. 
      Estimate measurements in cm based on their silhouette and position in the frame.
      Be realistic and accurate.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: [
          {
            parts: [
              { text: prompt },
              { inlineData: { mimeType: 'image/jpeg', data: base64Image } }
            ]
          }
        ],
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              gender: { type: Type.STRING, description: "Gender of the person: 'men' or 'women'" },
              height_cm: { type: Type.NUMBER, description: "Total height in cm" },
              weight_kg: { type: Type.NUMBER, description: "Estimated weight in kg" },
              chest_cm: { type: Type.NUMBER, description: "Chest circumference" },
              waist_cm: { type: Type.NUMBER, description: "Waist circumference" },
              hips_cm: { type: Type.NUMBER, description: "Hips circumference" },
              shoulder_cm: { type: Type.NUMBER, description: "Shoulder width" },
            },
            required: ["gender", "height_cm", "weight_kg", "chest_cm", "waist_cm", "hips_cm", "shoulder_cm"]
          }
        }
      });

      const result = JSON.parse(response.text || '{}');
      console.log("Verified AI Scan Result:", result);

      // 3. Navigate with data
      navigate('/app/profile/new', { state: { scannedMeasurements: result } });
    } catch (err) {
      console.error("Scanning failed:", err);
      navigate('/app/profile/new');
    } finally {
      setScanning(false);
    }
  };

  return (
    <AppLayout showNav={false}>
      <div className="space-y-6 pb-12 flex flex-col h-full">
        <header className="flex items-center space-x-4 rtl:space-x-reverse px-2">
          <button onClick={() => navigate('/app')} className="p-2 bg-zinc-100 rounded-full text-black border border-zinc-200 active:scale-90 transition-transform">
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={isRTL ? "M9 5l7 7-7 7" : "M15 19l-7-7 7-7"} />
            </svg>
          </button>
          <h1 className="text-xl font-bold text-black">{t('scanNow')}</h1>
        </header>

        <div className="relative flex-1 bg-black rounded-[3rem] overflow-hidden shadow-2xl min-h-[450px]">
           <video 
             ref={videoRef} 
             autoPlay 
             playsInline 
             muted 
             className="absolute inset-0 w-full h-full object-cover scale-x-[-1]"
           />
           
           <canvas ref={canvasRef} className="hidden" />

           {/* Scan Overlay */}
           <div className="absolute inset-0 flex flex-col items-center justify-center p-12 pointer-events-none">
              <div className="w-full h-full border-2 border-dashed border-white/30 rounded-[2.5rem] relative">
                 <div className="absolute top-1/4 left-0 right-0 h-0.5 bg-pink-400/50 shadow-[0_0_15px_rgba(244,114,182,0.8)] animate-bounce" />
                 <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-blue-400/50 shadow-[0_0_15px_rgba(96,165,250,0.8)]" />
                 <div className="absolute bottom-1/4 left-0 right-0 h-0.5 bg-yellow-400/50 shadow-[0_0_15px_rgba(250,204,21,0.1)]" />
              </div>
           </div>

           {scanning && (
             <div className="absolute inset-0 bg-black/60 backdrop-blur-md flex flex-col items-center justify-center space-y-6 z-50">
                <div className="w-20 h-20">
                   <img src={aiIconUrl} alt="Maqasee AI" className="w-full h-full object-contain animate-pulse" />
                </div>
                <div className="flex flex-col items-center space-y-2 px-12 text-center">
                   <div className="w-48 h-1.5 bg-white/20 rounded-full overflow-hidden">
                      <div className="h-full bg-white animate-[loading_2s_ease-in-out_infinite]" style={{width: '30%'}}></div>
                   </div>
                   <span className="text-white font-black uppercase tracking-[0.2em] text-[10px]">{status}</span>
                </div>
             </div>
           )}

           <div className="absolute bottom-8 left-0 right-0 flex justify-center px-8">
              <div className="bg-black/20 backdrop-blur-xl border border-white/10 p-4 rounded-3xl text-center">
                 <p className="text-white/90 text-[10px] font-black uppercase tracking-widest leading-relaxed">
                   {t('scanHelper')}
                 </p>
              </div>
           </div>
        </div>

        <Button 
          onClick={handleScan} 
          fullWidth 
          className="py-6 border-none shadow-xl shadow-[#B287CD]/10 active:scale-95"
          disabled={scanning}
        >
          {scanning ? t('loading') : t('scanNow')}
        </Button>
      </div>
      <style>{`
        @keyframes loading {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(250%); }
        }
      `}</style>
    </div>
  );
};