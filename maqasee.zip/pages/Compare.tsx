import React, { useEffect, useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { Card, Loading } from '../components/UI';
import { AppLayout } from '../components/Layout';
import { useNavigate } from 'react-router-dom';
import { auth } from '../firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { getProfiles } from '../services/firestore';
import { Profile, Measurements } from '../types';

export const Compare: React.FC = () => {
  const { t, isRTL } = useLanguage();
  const navigate = useNavigate();
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  
  const aiIconUrl = "https://i.postimg.cc/Qt6h8Yt7/MAQ-(3).png";

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      if (fbUser) {
        const allProfiles = await getProfiles(fbUser.uid);
        setProfiles(allProfiles);
        // Default to comparing the first two profiles if available
        if (allProfiles.length >= 2) {
          setSelectedIds([allProfiles[0].id, allProfiles[1].id]);
        }
      } else {
        navigate('/auth');
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, [navigate]);

  const toggleProfile = (id: string) => {
    if (selectedIds.includes(id)) {
      setSelectedIds(selectedIds.filter(x => x !== id));
    } else {
      if (selectedIds.length < 2) {
        setSelectedIds([...selectedIds, id]);
      } else {
        // Swap out the last selected if we're at limit
        setSelectedIds([selectedIds[1], id]);
      }
    }
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-zinc-50">
      <Loading />
    </div>
  );

  const selectedProfiles = profiles.filter(p => selectedIds.includes(p.id));
  const metrics: Array<keyof Measurements> = ['height_cm', 'weight_kg', 'chest_cm', 'waist_cm', 'hips_cm'];

  return (
    <AppLayout>
      <div className="space-y-8 pb-12">
        <header className="flex items-center space-x-4 rtl:space-x-reverse">
          <button onClick={() => navigate('/app')} className="p-2 bg-zinc-100 rounded-full active:scale-90 transition-transform">
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={isRTL ? "M9 5l7 7-7 7" : "M15 19l-7-7 7-7"} />
            </svg>
          </button>
          <h1 className="text-2xl font-bold text-black">{t('compare')}</h1>
        </header>

        <div className="space-y-4">
           <p className="text-[10px] font-black uppercase text-zinc-400 tracking-widest px-2">{t('selectProfile')} (max 2)</p>
           <div className="flex overflow-x-auto hide-scrollbar space-x-4 rtl:space-x-reverse py-1 px-1">
              {profiles.map(p => (
                <button
                  key={p.id}
                  onClick={() => toggleProfile(p.id)}
                  className={`flex flex-col items-center space-y-2 shrink-0 transition-all ${selectedIds.includes(p.id) ? 'scale-110' : 'opacity-60'}`}
                >
                  <div className={`w-14 h-14 rounded-3xl flex items-center justify-center text-lg font-black ${selectedIds.includes(p.id) ? 'ring-4 ring-black/5 bg-black text-white' : 'bg-zinc-100 text-zinc-400'}`}>
                    {p.name.charAt(0).toUpperCase()}
                  </div>
                  <span className="text-[9px] font-bold uppercase truncate max-w-[60px]">{p.name}</span>
                </button>
              ))}
           </div>
        </div>

        {selectedProfiles.length === 2 ? (
          <Card className="space-y-6">
             <div className="grid grid-cols-3 gap-2 border-b border-zinc-50 pb-4">
                <div className="text-[10px] font-black uppercase text-zinc-400">{t('measurements')}</div>
                <div className="text-center font-black text-xs truncate">{selectedProfiles[0].name}</div>
                <div className="text-center font-black text-xs truncate">{selectedProfiles[1].name}</div>
             </div>
             {metrics.map(m => {
               const val1 = selectedProfiles[0].measurements[m] || 0;
               const val2 = selectedProfiles[1].measurements[m] || 0;
               return (
                 <div key={m} className="grid grid-cols-3 gap-2 items-center">
                    <div className="text-[10px] font-bold text-zinc-500 uppercase">{t(m.split('_')[0] as any)}</div>
                    <div className="text-center font-black text-sm">{val1}</div>
                    <div className="text-center font-black text-sm">{val2}</div>
                 </div>
               );
             })}
          </Card>
        ) : (
          <div className="py-20 text-center text-zinc-400 text-sm italic">
            {t('selectProfile')}...
          </div>
        )}

        <div className="flex bg-[#F0FDF4] p-5 rounded-3xl border border-green-100 items-start space-x-3 rtl:space-x-reverse">
           <div className="w-10 h-10 shrink-0">
              <img src={aiIconUrl} alt="Maqasee AI" className="w-full h-full object-contain" />
           </div>
           <div className="space-y-1">
              <h4 className="text-[10px] font-black uppercase text-green-600 tracking-widest">{t('aiInsight')}</h4>
              <p className="text-xs font-medium text-zinc-600 leading-relaxed">
                {t('compareAdvice')}
              </p>
           </div>
        </div>
      </div>
    </AppLayout>
  );
};