
import React, { useEffect, useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { Card, Loading } from '../components/UI';
import { AppLayout } from '../components/Layout';
import { useNavigate } from 'react-router-dom';
import { auth } from '../firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { getProfiles } from '../services/firestore';
import { Profile, Measurements } from '../types';
import { COLORS } from '../constants';

export const Compare: React.FC = () => {
  // Fix: Destructured 'language' from useLanguage to resolve the undefined variable error in the JSX
  const { t, isRTL, language } = useLanguage();
  const navigate = useNavigate();
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  
  const aiIconUrl = "https://i.postimg.cc/Qt6h8Yt7/MAQ-(3).png";

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      if (fbUser) {
        const allProfiles = await getProfiles(fbUser.uid);
        setProfiles(allProfiles);
        // Default to comparing the first two profiles if available
        if (allProfiles.length >= 2) {
          setSelectedIds([allProfiles[0].id, allProfiles[1].id]);
        }
      } else {
        navigate('/auth');
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, [navigate]);

  const toggleProfile = (id: string) => {
    if (selectedIds.includes(id)) {
      setSelectedIds(selectedIds.filter(x => x !== id));
    } else {
      if (selectedIds.length < 2) {
        setSelectedIds([...selectedIds, id]);
      } else {
        // Swap out the last selected if we're at limit
        setSelectedIds([selectedIds[1], id]);
      }
    }
  };

  const getAvatarColor = (name: string) => {
    const hash = name.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    const colors = [COLORS.yellow, COLORS.pink, COLORS.sage, COLORS.salmon];
    return colors[hash % colors.length];
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-zinc-50">
      <Loading />
    </div>
  );

  const selectedProfiles = profiles.filter(p => selectedIds.includes(p.id));
  const metrics: Array<keyof Measurements> = [
    'height_cm', 
    'weight_kg', 
    'chest_cm', 
    'waist_cm', 
    'hips_cm', 
    'shoulder_cm', 
    'neck_cm'
  ];

  return (
    <AppLayout>
      <div className="space-y-8 pb-12">
        <header className="flex items-center space-x-4 rtl:space-x-reverse">
          <button onClick={() => navigate('/app')} className="p-2 bg-zinc-100 rounded-full active:scale-90 transition-transform border border-zinc-200">
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={isRTL ? "M9 5l7 7-7 7" : "M15 19l-7-7 7-7"} />
            </svg>
          </button>
          <h1 className="text-2xl font-black text-black">{t('compare')}</h1>
        </header>

        <div className="space-y-4">
           <p className="text-[10px] font-black uppercase text-zinc-400 tracking-widest px-2">{t('selectProfile')} (max 2)</p>
           <div className="flex overflow-x-auto hide-scrollbar space-x-5 rtl:space-x-reverse py-4 px-1">
              {profiles.map(p => {
                const isSelected = selectedIds.includes(p.id);
                return (
                  <button
                    key={p.id}
                    onClick={() => toggleProfile(p.id)}
                    className={`flex flex-col items-center space-y-3 shrink-0 transition-all duration-300 ${isSelected ? 'scale-110' : 'opacity-40 grayscale-[0.5]'}`}
                  >
                    <div 
                      className={`w-16 h-16 rounded-[1.75rem] flex items-center justify-center text-xl font-black shadow-lg transition-all ${isSelected ? 'ring-4 ring-[#89A7A1]/20' : ''}`}
                      style={{ backgroundColor: isSelected ? '#89A7A1' : getAvatarColor(p.name), color: 'white' }}
                    >
                      {p.name.charAt(0).toUpperCase()}
                    </div>
                    <span className={`text-[9px] font-black uppercase truncate max-w-[64px] ${isSelected ? 'text-black' : 'text-zinc-400'}`}>{p.name}</span>
                  </button>
                );
              })}
           </div>
        </div>

        {selectedProfiles.length === 2 ? (
          <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <Card className="space-y-8 overflow-hidden relative" bgColor="bg-white">
              <div className="absolute top-0 left-1/2 -translate-x-1/2 w-0.5 h-full bg-zinc-50 hidden md:block"></div>
              
              <div className="grid grid-cols-3 gap-4 border-b border-zinc-50 pb-6 items-center">
                 <div className="text-[10px] font-black uppercase text-zinc-400 tracking-[0.2em]">{t('measurements')}</div>
                 <div className="text-center font-black text-xs text-[#89A7A1] uppercase tracking-widest truncate">{selectedProfiles[0].name}</div>
                 <div className="text-center font-black text-xs text-[#F08A82] uppercase tracking-widest truncate">{selectedProfiles[1].name}</div>
              </div>

              <div className="space-y-6">
                {metrics.map(m => {
                  const val1 = selectedProfiles[0].measurements[m] || 0;
                  const val2 = selectedProfiles[1].measurements[m] || 0;
                  const diff = val1 - val2;
                  
                  return (
                    <div key={m} className="grid grid-cols-3 gap-4 items-center">
                       <div className="space-y-0.5">
                          <span className="text-[10px] font-black text-zinc-600 uppercase tracking-widest">{t(m.split('_')[0] as any)}</span>
                          <span className="text-[8px] font-bold text-zinc-300 uppercase tracking-tighter block">{m.includes('kg') ? t('weightUnit') : t('metricUnit')}</span>
                       </div>
                       <div className="text-center font-black text-xl text-zinc-900">{val1}</div>
                       <div className="text-center font-black text-xl text-zinc-900">{val2}</div>
                    </div>
                  );
                })}
              </div>
            </Card>

            <div className="bg-[#F0FDF4]/60 backdrop-blur-xl p-8 rounded-[3rem] border border-green-100 flex items-start space-x-6 rtl:space-x-reverse shadow-sm">
               <div className="w-14 h-14 shrink-0 drop-shadow-lg">
                  <img src={aiIconUrl} alt="Maqasee AI" className="w-full h-full object-contain" />
               </div>
               <div className="space-y-2">
                  <h4 className="text-[10px] font-black uppercase text-green-700 tracking-[0.25em]">{t('aiInsight')}</h4>
                  <p className="text-sm font-medium text-zinc-700 leading-relaxed italic">
                    {t('compareAdvice')}
                  </p>
               </div>
            </div>
          </div>
        ) : (
          <div className="py-32 flex flex-col items-center justify-center text-center space-y-6 animate-in zoom-in duration-300">
            <div className="w-24 h-24 bg-zinc-100 rounded-full flex items-center justify-center">
              <svg className="w-10 h-10 text-zinc-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
              </svg>
            </div>
            <div className="space-y-2">
              <h3 className="text-lg font-black text-zinc-800 uppercase tracking-widest">{t('selectProfile')}</h3>
              <p className="text-sm text-zinc-400 font-medium">{language === 'ar' ? 'اختر ملفين للمقارنة' : 'Select two profiles to compare DNA.'}</p>
            </div>
          </div>
        )}
      </div>
    </AppLayout>
  );
};
