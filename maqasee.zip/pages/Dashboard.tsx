
import React, { useEffect, useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { Card, FloatingActionButton, useToast, Loading } from '../components/UI';
import { AppLayout } from '../components/Layout';
import { useNavigate } from 'react-router-dom';
import { auth } from '../firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { 
  getUserProfile, 
  getProfiles, 
  getRecentRecommendation, 
  updateActiveProfile,
  updateProfileFit,
  updateProfileStretch
} from '../services/firestore';
import { UserProfile, Profile, FitPreference, StretchTolerance, Recommendation } from '../types';
import { ICONS, COLORS } from '../constants';

export const Dashboard: React.FC = () => {
  const { t, language } = useLanguage();
  const { showToast } = useToast();
  const navigate = useNavigate();
  const [user, setUser] = useState<UserProfile | null>(null);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [activeProfile, setActiveProfile] = useState<Profile | null>(null);
  const [recentRec, setRecentRec] = useState<Recommendation | null>(null);
  const [loading, setLoading] = useState(true);

  // Fix: Property 'length' does not exist on type 'COLORS' object. Use local 'colors' array length.
  const getAvatarColor = (name: string) => {
    const hash = name.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    const colors = [COLORS.yellow, COLORS.pink, COLORS.sage, COLORS.salmon];
    return colors[hash % colors.length];
  };

  const loadData = async (uid: string, profileId?: string) => {
    const [userData, allProfiles] = await Promise.all([
      getUserProfile(uid),
      getProfiles(uid)
    ]);
    
    setUser(userData);
    setProfiles(allProfiles);
    
    const targetId = profileId || userData?.activeProfileId || allProfiles[0]?.id;
    if (targetId) {
      const p = allProfiles.find(x => x.id === targetId);
      setActiveProfile(p || null);
      const rec = await getRecentRecommendation(uid, targetId);
      setRecentRec(rec);
    }
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      if (fbUser) {
        await loadData(fbUser.uid);
      } else {
        navigate('/auth');
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, [navigate]);

  const handleSwitchProfile = async (id: string) => {
    if (!user) return;
    setLoading(true);
    await updateActiveProfile(user.uid, id);
    await loadData(user.uid, id);
    setLoading(false);
    showToast(t('switchProfile'));
  };

  const handleFitChange = async (pref: FitPreference) => {
    if (!user || !activeProfile) return;
    setActiveProfile({ ...activeProfile, fitPreference: pref });
    await updateProfileFit(user.uid, activeProfile.id, pref);
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-[#F7F1E5]">
      <Loading />
    </div>
  );

  const measurements = activeProfile?.measurements || {};
  const completedCount = Object.values(measurements).filter(v => v !== undefined && v !== null).length;
  const totalMetrics = 11;
  const completion = Math.round((completedCount / totalMetrics) * 100);
  const score = completion > 0 ? (completion / 10).toFixed(1) : "0.0";

  // Circular progress calculations
  const radius = 22;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (completion / 100) * circumference;

  return (
    <AppLayout>
      <div className="space-y-10 pb-12">
        <header className="flex flex-col space-y-8">
          <div className="flex justify-between items-start px-2">
            <div className="space-y-1">
              <h2 className="text-zinc-600 text-[10px] font-black uppercase tracking-[0.3em]">{t('welcome')}</h2>
              <div className="flex items-center space-x-3 rtl:space-x-reverse">
                 <h1 className="text-3xl font-black text-black tracking-tight">{user?.name || 'User'}</h1>
                 {user?.isAdmin && (
                   <button onClick={() => navigate('/admin')} className="p-2 bg-[#89A7A1] rounded-xl text-white shadow-lg shadow-[#89A7A1]/10 transition-all active:scale-95">
                     {ICONS.admin("w-4 h-4")}
                   </button>
                 )}
              </div>
            </div>
            <div className="flex space-x-3 rtl:space-x-reverse">
               <button onClick={() => navigate('/app/history')} className="w-12 h-12 bg-white border border-zinc-100 rounded-2xl flex items-center justify-center hover:bg-zinc-50 shadow-sm transition-all active:scale-90">{ICONS.history("w-5 h-5 text-zinc-900")}</button>
               <button onClick={() => auth.signOut()} className="w-12 h-12 bg-zinc-50 rounded-2xl flex items-center justify-center hover:bg-zinc-100 transition-all active:scale-90 text-zinc-600">
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>
               </button>
            </div>
          </div>

          <div className="space-y-4">
             <div className="flex justify-between items-center px-2">
               <p className="text-[10px] font-black uppercase text-zinc-600 tracking-[0.2em]">{t('sizeFriends')}</p>
               <button onClick={() => navigate('/app/friends')} className="text-[9px] font-black uppercase text-[#F08A82] tracking-widest">{t('viewAll')}</button>
             </div>
             <div className="flex overflow-x-auto hide-scrollbar space-x-5 rtl:space-x-reverse py-2 px-2 items-center">
                {profiles.map(p => (
                  <button
                    key={p.id}
                    onClick={() => handleSwitchProfile(p.id)}
                    className="flex flex-col items-center space-y-3 shrink-0 group"
                  >
                    <div className={`w-16 h-16 rounded-[1.75rem] flex items-center justify-center text-xl font-black transition-all duration-500 ${
                      activeProfile?.id === p.id 
                      ? 'bg-[#F08A82] text-white shadow-xl shadow-[#F08A82]/10 scale-110' 
                      : 'text-zinc-600 border border-zinc-100'
                    }`} style={{ backgroundColor: activeProfile?.id === p.id ? '' : getAvatarColor(p.name) }}>
                      {p.name.charAt(0).toUpperCase()}
                    </div>
                    <span className={`text-[9px] font-black uppercase tracking-widest truncate max-w-[64px] transition-colors ${activeProfile?.id === p.id ? 'text-zinc-900' : 'text-zinc-500'}`}>
                       {p.name}
                    </span>
                  </button>
                ))}
                <button 
                  onClick={() => navigate('/app/profile/new')}
                  className="flex flex-col items-center space-y-3 shrink-0 group"
                >
                  <div className="w-16 h-16 rounded-[1.75rem] border-2 border-dashed border-zinc-300 flex items-center justify-center text-zinc-400 group-hover:border-zinc-500 group-hover:text-zinc-600 transition-all duration-300">
                    {ICONS.add("w-7 h-7")}
                  </div>
                  <span className="text-[9px] font-black uppercase text-zinc-400 tracking-widest">{t('friend')}</span>
                </button>
             </div>
          </div>
        </header>

        {/* Sleek Score Card */}
        <Card className="flex flex-col items-center py-12 space-y-6 relative overflow-hidden group border-none" bgColor="bg-white">
          <div className="absolute inset-0 bg-gradient-to-b from-zinc-50/50 to-transparent pointer-events-none group-hover:scale-110 transition-transform duration-1000"></div>
          <div className="relative z-10 flex flex-col items-center">
            <span className="text-9xl font-black text-zinc-900 tracking-tighter drop-shadow-sm select-none">{score}</span>
            <div className="mt-4 px-4 py-1.5 bg-[#F08A82] rounded-full text-[8px] font-black text-white uppercase tracking-[0.25em] shadow-lg shadow-[#F08A82]/10">{t('verifiedFit')}</div>
          </div>
          <p className="text-zinc-600 text-[10px] font-black uppercase tracking-[0.3em] z-10 pt-2 opacity-80">
            {activeProfile?.name} • {t('yourSizeToday')}
          </p>
        </Card>

        {/* Action Buttons Grid - Re-styled with requested Box Colors */}
        <div className="grid grid-cols-2 gap-5">
          {/* Body Scan (Soft Pink) */}
          <button 
            onClick={() => navigate('/app/scan')} 
            className="bg-[#F6CDC4] p-7 rounded-[3rem] border border-white/20 flex flex-col items-center justify-center space-y-4 active:scale-95 transition-all shadow-[0_20px_40px_-15px_rgba(246,205,196,0.3)] group"
          >
            <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform shadow-sm">
              {ICONS.scan("w-8 h-8 text-[#F08A82]")}
            </div>
            <span className="font-black text-[10px] uppercase tracking-[0.2em] text-zinc-900">{t('scanNow')}</span>
          </button>
          
          {/* SnapShop (Yellow/Gold) */}
          <button 
            onClick={() => navigate('/app/snapshop')} 
            className="bg-[#F1B95B] p-7 rounded-[3rem] border border-white/20 flex flex-col items-center justify-center space-y-4 active:scale-95 transition-all shadow-[0_20px_40px_-15px_rgba(241,185,91,0.3)] group"
          >
            <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform shadow-sm">
              {ICONS.snapshop("w-8 h-8 text-[#F1B95B]")}
            </div>
            <span className="font-black text-[10px] uppercase tracking-[0.2em] text-zinc-900">{t('snapShop')}</span>
          </button>
        </div>

        {recentRec && (
          <button onClick={() => navigate('/app/history')} className="w-full bg-white p-6 rounded-[2.5rem] border border-zinc-100 flex items-center justify-between active:scale-95 transition-all shadow-sm group hover:border-[#89A7A1]/20 hover:shadow-xl hover:shadow-[#89A7A1]/[0.03]">
            <div className="flex flex-col items-start text-left rtl:text-right">
              <p className="text-[8px] font-black uppercase text-[#89A7A1] tracking-widest mb-1.5">{t('recentSearch')}</p>
              <h4 className="font-black text-sm text-zinc-900 capitalize truncate max-w-[200px]">{recentRec.platform} • {recentRec.recommendedSize}</h4>
            </div>
            <div className="w-12 h-12 bg-[#89A7A1]/10 rounded-full flex items-center justify-center font-black text-xs text-[#89A7A1] transition-transform group-hover:scale-110">{recentRec.confidence}%</div>
          </button>
        )}

        {/* Sleek Stats Grid */}
        <div className="grid grid-cols-2 gap-5">
          <Card className="flex flex-col justify-between h-48 border-none bg-white/40" bgColor="bg-white/40">
            <span className="text-zinc-600 text-[9px] font-black uppercase tracking-[0.25em]">{t('measurements')}</span>
            <div className="flex flex-col space-y-1">
               <span className="text-5xl font-black text-zinc-900 tracking-tighter">{completedCount}</span>
               <span className="text-[9px] font-black text-zinc-500 uppercase tracking-widest">{t('totalMetrics')}</span>
            </div>
          </Card>
          
          <Card className="flex flex-col justify-between h-48 border-none bg-[#89A7A1] text-white overflow-hidden relative" bgColor="bg-[#89A7A1]">
            <div className="absolute top-6 right-6 rtl:left-6 rtl:right-auto">
               <svg className="w-14 h-14 -rotate-90" viewBox="0 0 56 56">
                  <circle cx="28" cy="28" r={radius} fill="transparent" stroke="rgba(255,255,255,0.2)" strokeWidth="4" />
                  <circle cx="28" cy="28" r={radius} fill="transparent" stroke="white" strokeWidth="4" strokeDasharray={circumference} strokeDashoffset={offset} className="transition-all duration-1000 ease-out" strokeLinecap="round" />
               </svg>
            </div>
            <span className="text-white/70 text-[9px] font-black uppercase tracking-[0.25em]">{t('completion')}</span>
            <div className="flex flex-col space-y-1">
               <span className="text-5xl font-black text-white tracking-tighter">{completion}%</span>
               <span className="text-[9px] font-black text-white/70 uppercase tracking-widest">{t('profileComplete')}</span>
            </div>
          </Card>
        </div>

        {/* Fit Preference Toggles */}
        <div className="space-y-6">
          <h3 className="text-[10px] font-black uppercase tracking-[0.3em] text-zinc-600 px-2">{t('fitPref')}</h3>
          <div className="grid grid-cols-3 gap-4">
             {(['tight', 'regular', 'oversized'] as FitPreference[]).map((p) => {
               const isActive = activeProfile?.fitPreference === p;
               return (
                 <button 
                    key={p} 
                    onClick={() => handleFitChange(p)} 
                    className={`py-6 rounded-[2rem] border transition-all duration-300 group ${
                      isActive 
                      ? 'bg-[#F08A82] text-white border-[#F08A82] shadow-xl shadow-[#F08A82]/10 scale-105 z-10' 
                      : 'bg-white text-zinc-600 border-zinc-100 hover:border-zinc-300'
                    }`}
                 >
                   <span className="text-[9px] font-black uppercase tracking-widest">{t(p)}</span>
                 </button>
               );
             })}
          </div>
        </div>
      </div>
    </AppLayout>
  );
};
