import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { Button, Card } from '../components/UI';
import { useNavigate } from 'react-router-dom';
import { ICONS } from '../constants';

// Fixed White/Silver Premium Phone Frame to match the reference image exactly
const AppFrame: React.FC<{ imageUrl: string, className?: string, children?: React.ReactNode }> = ({ imageUrl, className = "", children }) => (
  <div className={`relative w-[280px] md:w-[340px] h-[580px] md:h-[700px] bg-white rounded-[3.5rem] p-[8px] shadow-[0_40px_100px_-20px_rgba(0,0,0,0.2)] border-[1.5px] border-zinc-200 ring-1 ring-black/5 ${className}`}>
     {/* Traditional Notch aligned to the top bezel */}
     <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-6 bg-black rounded-b-[1.25rem] z-50 flex items-center justify-center">
        <div className="w-10 h-1 bg-zinc-800 rounded-full opacity-50"></div>
     </div>
     
     {/* Inner Screen with thin black border for high-fidelity look */}
     <div className="w-full h-full bg-black rounded-[2.8rem] p-[2px] overflow-hidden relative group">
        <div className="w-full h-full bg-white rounded-[2.7rem] overflow-hidden relative">
          <img 
            src={imageUrl} 
            className="w-full h-full object-cover object-top transition-transform duration-700 group-hover:scale-105" 
            alt="App UI" 
          />
          {/* Subtle screen glare/reflection */}
          <div className="absolute inset-0 bg-gradient-to-tr from-white/10 via-transparent to-black/5 pointer-events-none" />
        </div>
        {children}
     </div>
  </div>
);

export const Landing: React.FC = () => {
  const { t, setLanguage, language, isRTL } = useLanguage();
  const navigate = useNavigate();
  
  // Use the primary main logo for both languages
  const logoUrl = "https://i.postimg.cc/tCD6Wpcg/Chat-GPT-Image-Jan-30-2026-02-19-49-PM.png";

  /**
   * Multi-Language Mockup Mapping:
   * We swap the entire set based on the active language.
   */
  const allScreenshots = {
    en: {
      hero: "https://i.postimg.cc/VNWfnYfr/Frames.png",      // Mockup A (EN)
      scan: "https://i.postimg.cc/k4525Vxh/Frames-1.png",    // Mockup B (EN)
      save: "https://i.postimg.cc/0N7QnTvJ/Frames-2.png",    // Mockup C (EN)
      search: "https://i.postimg.cc/3RBw52dd/Frames-3.png",  // Mockup D (EN)
      shop: "https://i.postimg.cc/nLfVX3mX/Frames-4.png"    // Mockup E (EN)
    },
    ar: {
      hero: "https://i.postimg.cc/MKrYRFzp/Frames-A1.png",    // Mockup A (AR)
      scan: "https://i.postimg.cc/YCMmvNWw/Frames-A2.png",    // Mockup B (AR)
      save: "https://i.postimg.cc/tggZ5XD0/Frames-A3.png",    // Mockup C (AR)
      search: "https://i.postimg.cc/tTKspFjd/Frames-A4.png",  // Mockup D (AR)
      shop: "https://i.postimg.cc/BZF8N7Tr/Frames-A5.png"    // Mockup E (AR)
    }
  };

  // Get the current set based on language state
  const screenshots = allScreenshots[language];

  const leaders = [
    {
      name: t('ceoName'),
      title: t('ceoTitle'),
      quote: t('ceoQuote'),
      photo: "https://i.postimg.cc/DZbt1hK7/qq-Edited-PNG.png",
      color: "bg-[#F1B95B]/20"
    },
    {
      name: t('ctoName'),
      title: t('ctoTitle'),
      quote: t('ctoQuote'),
      photo: "https://i.postimg.cc/JhsgW80W/q-PNG.png",
      color: "bg-[#89A7A1]/20"
    }
  ];

  const [activeCity, setActiveCity] = useState<'Dubai' | 'London' | 'NewYork'>('Dubai');
  const cityData = {
    Dubai: { label: t('dubai'), eu: '44', us: '12', uk: '16', jp: '15' },
    London: { label: t('london'), eu: '46', us: '14', uk: '18', jp: '17' },
    NewYork: { label: t('newYork'), eu: '42', us: '10', uk: '14', jp: '13' }
  };

  const processSteps = [
    { 
      id: 1, 
      title: t('step1Scan'), 
      desc: t('step1ScanDesc'), 
      img: screenshots.scan, 
      badge: t('badgeScan'), 
      color: "bg-[#F6CDC4]", 
      badgeColor: "bg-[#F6CDC4] text-[#F08A82]" 
    },
    { 
      id: 2, 
      title: t('step2Save'), 
      desc: t('step2SaveDesc'), 
      img: screenshots.save, 
      badge: t('badgeVault'), 
      color: "bg-[#F7F1E5]", 
      badgeColor: "bg-zinc-200 text-zinc-600" 
    },
    { 
      id: 3, 
      title: t('step3Search'), 
      desc: t('step3SearchDesc'), 
      img: screenshots.search, 
      badge: t('badgeStyles'), 
      color: "bg-[#89A7A1]/10", 
      badgeColor: "bg-[#89A7A1]/20 text-[#89A7A1]" 
    },
    { 
      id: 4, 
      title: t('step4Shop'), 
      desc: t('step4ShopDesc'), 
      img: screenshots.shop, 
      badge: t('badgeGlobal'), 
      color: "bg-[#F1B95B]/10", 
      badgeColor: "bg-[#F1B95B]/20 text-[#F1B95B]" 
    }
  ];

  const perkKeys = ['perkAccuracy', 'perkConversion', 'perkPredictions'] as const;
  const quoteKeys = ['quote1', 'quote2', 'quote3'] as const;

  return (
    <div className="min-h-screen bg-white selection:bg-[#F08A82]/10 overflow-x-hidden font-['Inter',_sans-serif] rtl:font-['Tajawal',_sans-serif]">
      {/* Navigation */}
      <header className="fixed top-0 left-0 right-0 z-[100] bg-white/70 backdrop-blur-3xl border-b border-zinc-100">
        <div className="max-w-7xl mx-auto px-6 md:px-12 h-20 flex items-center justify-between">
          <div className="flex items-center space-x-3 rtl:space-x-reverse">
            <div className="w-10 h-10 bg-white rounded-xl shadow-soft p-1.5 border border-zinc-50">
               <img src={logoUrl} alt="Maqasee" className="w-full h-full object-contain" />
            </div>
            <span className="font-black text-lg tracking-tighter text-black uppercase">{t('appName')}</span>
          </div>
          
          <div className="flex items-center space-x-4 md:space-x-8 rtl:space-x-reverse">
            <div className="hidden md:flex bg-zinc-100/50 p-1 rounded-full border border-zinc-200/40">
              <button onClick={() => setLanguage('en')} className={`px-4 py-1.5 rounded-full text-[10px] font-black transition-all ${language === 'en' ? 'bg-white text-black shadow-sm' : 'text-zinc-500'}`}>EN</button>
              <button onClick={() => setLanguage('ar')} className={`px-4 py-1.5 rounded-full text-[10px] font-black transition-all ${language === 'ar' ? 'bg-white text-black shadow-sm' : 'text-zinc-500'}`}>AR</button>
            </div>
            <button onClick={() => navigate('/auth')} className="text-[10px] font-black uppercase tracking-widest text-zinc-900 hover:text-[#F08A82] transition-colors">{t('login')}</button>
            <Button onClick={() => navigate('/auth')} className="!py-3 !px-8 !text-[10px]">{t('signup')}</Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative pt-48 pb-32 px-6 overflow-hidden bg-[#F7F1E5]/40">
        <div className="absolute top-[-20%] left-[-10%] w-[800px] h-[800px] bg-[#F1B95B]/20 organic-shape blur-[160px] animate-pulse"></div>
        <div className="max-w-7xl mx-auto text-center space-y-16 relative z-10">
          <div className="space-y-8 flex flex-col items-center">
            <h1 className="text-5xl md:text-9xl font-black text-black tracking-tighter leading-[0.9] max-w-5xl mx-auto uppercase animate-in fade-in slide-in-from-bottom-10 duration-1000">
               {t('heroTitle')}
            </h1>
            <p className="text-lg md:text-xl text-zinc-500 font-medium max-w-2xl mx-auto leading-relaxed animate-in fade-in slide-in-from-bottom-10 duration-1000 delay-200 mt-60">
               {t('heroDesc')}
            </p>
            <div className="pt-8">
              <Button onClick={() => navigate('/auth')} className="!py-6 !px-12 !text-xs shadow-heavy group animate-in fade-in zoom-in duration-1000 delay-500">
                <div className="flex items-center space-x-3 rtl:space-x-reverse">
                  <span>{t('startJourney')}</span>
                  <svg className="w-4 h-4 group-hover:translate-x-1 rtl:group-hover:-translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={isRTL ? "M15 19l-7-7 7-7" : "M9 5l7 7-7 7"} />
                  </svg>
                </div>
              </Button>
            </div>
          </div>
          <div className="flex justify-center pt-10">
             <AppFrame imageUrl={screenshots.hero} className="rotate-2" />
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-40 px-6 bg-white overflow-hidden">
         <div className="max-w-7xl mx-auto space-y-32 md:space-y-64 relative">
            <div className="text-center space-y-6 relative z-10 mb-20 md:mb-40">
               <span className="px-6 py-2.5 bg-zinc-900 text-white rounded-full text-[11px] font-black uppercase tracking-[0.3em]">{t('featuresTitle')}</span>
               <h2 className="text-4xl md:text-8xl font-black text-black tracking-tighter leading-tight max-w-4xl mx-auto uppercase">
                 {language === 'ar' ? 'رحلة مقاسك المثالي' : 'Your Perfect Fit Journey'}
               </h2>
            </div>

            {processSteps.map((step, idx) => {
              const isEven = idx % 2 === 1;
              return (
                <div 
                  key={step.id} 
                  className={`flex flex-col md:flex-row items-center gap-16 md:gap-40 ${isEven ? 'md:flex-row-reverse' : ''} relative z-10`}
                >
                   <div className="flex-1 flex justify-center relative perspective-[1200px] animate-in slide-in-from-bottom-20 duration-1000">
                      <div className={`absolute inset-0 ${step.color} opacity-40 blur-[120px] rounded-full`} />
                      <AppFrame 
                        imageUrl={step.img} 
                        className={`transition-all duration-700 hover:-translate-y-4 ${isEven ? 'rotate-[-3deg]' : 'rotate-[3deg]'}`}
                      />
                   </div>

                   <div className="flex-1 space-y-10 text-center md:text-left rtl:md:text-right px-4">
                      <div className="space-y-8">
                         <div className="flex flex-col items-center md:items-start rtl:items-center rtl:md:items-end space-y-4">
                            <span className={`px-5 py-2 rounded-full ${step.badgeColor} text-[10px] font-black uppercase tracking-[0.2em] shadow-sm`}>
                               {step.badge}
                            </span>
                            <h3 className="text-5xl md:text-[5.5rem] font-black text-black tracking-tighter leading-[0.85] uppercase">
                               {step.title}
                            </h3>
                         </div>
                         <p className="text-xl md:text-2xl text-zinc-500 font-medium leading-relaxed max-w-lg mx-auto md:mx-0">
                            {step.desc}
                         </p>
                      </div>

                      <div className="flex flex-col items-center md:items-start rtl:items-center rtl:md:items-end">
                         <button onClick={() => navigate('/auth')} className="flex items-center space-x-4 rtl:space-x-reverse group">
                            <span className="text-xs font-black uppercase tracking-[0.2em] text-black border-b-2 border-transparent group-hover:border-black transition-all pb-1">
                               {t('tryMaqasee')}
                            </span>
                            <div className="w-10 h-10 rounded-full bg-zinc-900 text-white flex items-center justify-center transition-all group-hover:scale-110 group-hover:bg-[#F08A82]">
                               <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d={isRTL ? "M15 19l-7-7 7-7" : "M9 5l7 7-7 7"} />
                               </svg>
                            </div>
                         </button>
                      </div>
                   </div>
                </div>
              );
            })}
         </div>
      </section>

      {/* Leadership Section */}
      <section className="py-40 px-6 bg-[#F7F1E5]/20 relative overflow-hidden">
        <div className="max-w-7xl mx-auto space-y-24">
          <div className="text-center space-y-6">
            <span className="px-5 py-2 bg-[#F08A82]/10 text-[#F08A82] rounded-full text-[10px] font-black uppercase tracking-[0.2em]">{t('leadershipTitle')}</span>
            <h2 className="text-4xl md:text-7xl font-black text-black tracking-tighter leading-tight uppercase">
              {language === 'ar' ? 'الرؤية خلف مقاسي' : 'The Visionaries Behind Maqasee'}
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 lg:gap-24">
            {leaders.map((leader, i) => (
              <Card key={i} className="group p-0 overflow-hidden !rounded-[4rem] border-none shadow-heavy hover:-translate-y-4 transition-all duration-700 bg-white">
                <div className="flex flex-col h-full">
                  <div className={`relative h-[400px] overflow-hidden ${leader.color}`}>
                    <img src={leader.photo} className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110" alt={leader.name} />
                    <div className="absolute inset-0 bg-gradient-to-t from-white via-transparent to-transparent opacity-60"></div>
                  </div>
                  <div className="p-12 space-y-8 relative">
                    <div className="space-y-2">
                      <h3 className="text-4xl font-black text-black tracking-tighter uppercase">{leader.name}</h3>
                      <p className="text-sm font-black text-[#F08A82] uppercase tracking-widest">{leader.title}</p>
                    </div>
                    <div className="relative">
                      <span className="absolute top-[-20px] left-[-10px] text-8xl text-[#F08A82]/10 font-serif leading-none">“</span>
                      <p className="text-xl md:text-2xl text-zinc-600 font-medium leading-relaxed italic relative z-10">
                        {leader.quote}
                      </p>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Global Map Section */}
      <section className="py-40 px-6 bg-[#89A7A1] relative overflow-hidden border-y border-white/10">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center gap-16 md:gap-32">
          <div className="flex-1 space-y-8">
            <span className="px-5 py-2 bg-white/10 text-white border border-white/20 rounded-full text-[10px] font-black uppercase tracking-[0.2em]">{t('shopWorldTitle')}</span>
            <h2 className="text-4xl md:text-7xl font-black text-white tracking-tighter leading-tight uppercase">{t('shopWorldTitle')}</h2>
            <p className="text-xl text-white/70 font-medium leading-relaxed max-w-md">{t('shopWorldDesc')}</p>
            <div className="flex flex-wrap gap-4">
               {(['Dubai', 'London', 'NewYork'] as const).map(city => (
                 <button key={city} onClick={() => setActiveCity(city)} className={`px-8 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${activeCity === city ? 'bg-white text-[#89A7A1] shadow-heavy' : 'bg-white/10 text-white hover:bg-white/20 border border-white/10'}`}>{cityData[city].label}</button>
               ))}
            </div>
          </div>

          <div className="flex-1 relative w-full h-[500px] flex items-center justify-center">
             <div className="absolute inset-0 bg-white/20 blur-[140px] organic-shape"></div>
             <Card className="w-[340px] p-10 space-y-10 shadow-heavy border-zinc-100 scale-110 relative z-20" bgColor="bg-white">
                <div className="flex items-center space-x-6 rtl:space-x-reverse border-b border-zinc-100 pb-8">
                   {ICONS.pin("w-20 h-20")}
                   <span className="font-black text-xl text-zinc-900 uppercase tracking-[0.1em]">{cityData[activeCity].label}</span>
                </div>
                <div className="grid grid-cols-2 gap-8">
                   {[
                     { id: 'us', val: cityData[activeCity].us },
                     { id: 'uk', val: cityData[activeCity].uk },
                     { id: 'eu', val: cityData[activeCity].eu },
                     { id: 'jp', val: cityData[activeCity].jp }
                   ].map(item => (
                     <div key={item.id} className="space-y-1">
                        <span className="text-[10px] font-black uppercase text-zinc-400 tracking-tighter">{t(item.id as any)}</span>
                        <div className="text-4xl font-black text-zinc-900 animate-in fade-in zoom-in duration-500">{item.val}</div>
                     </div>
                   ))}
                </div>
             </Card>
          </div>
        </div>
      </section>

      {/* Before & After Section */}
      <section className="py-20 bg-white">
         <div className="max-w-[1400px] mx-auto grid grid-cols-1 md:grid-cols-2 min-h-[800px] rounded-[5rem] overflow-hidden shadow-[0_50px_100px_-30px_rgba(0,0,0,0.15)] mx-4 md:mx-12 border border-zinc-100">
            {/* Traditional Shopping */}
            <div className="bg-[#F7F1E5] p-12 md:p-24 flex flex-col justify-start pt-24 md:pt-40">
               <div className="space-y-6 min-h-[160px] md:min-h-[200px]">
                  <span className="text-[11px] font-black uppercase text-zinc-900/60 tracking-[0.3em] block h-6">{t('traditionalShopping')}</span>
                  <h2 className="text-5xl md:text-7xl font-black text-black tracking-tighter uppercase leading-[0.9]">{t('traditionalShopping')}</h2>
               </div>
               <div className="space-y-8 min-h-[240px]">
                  {quoteKeys.map((key, i) => (
                    <div key={i} className="flex items-center space-x-5 rtl:space-x-reverse h-[60px]">
                       <div className="w-10 h-10 rounded-full border border-zinc-900/10 flex items-center justify-center text-sm font-black text-zinc-900/30 shrink-0">×</div>
                       <p className="text-black font-bold italic text-xl leading-relaxed">{t(key)}</p>
                    </div>
                  ))}
               </div>
               <p className="text-black/60 font-medium leading-relaxed max-w-sm text-lg mt-20">{t('traditionalDesc')}</p>
            </div>

            {/* Maqasee Experience */}
            <div className="bg-[#F08A82] text-white p-12 md:p-24 flex flex-col justify-start pt-24 md:pt-40 relative overflow-hidden group">
               <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-white/10 blur-[150px] organic-shape" />
               <div className="space-y-6 relative z-10 min-h-[160px] md:min-h-[200px]">
                  <span className="text-[11px] font-black uppercase text-white/60 tracking-[0.3em] block h-6">{t('maqaseeExperience')}</span>
                  <h2 className="text-5xl md:text-7xl font-black text-white tracking-tighter uppercase leading-[0.9]">{t('maqaseeExperience')}</h2>
               </div>
               <div className="space-y-8 relative z-10 min-h-[240px]">
                  {perkKeys.map((perk, i) => (
                    <div key={i} className="flex items-center space-x-6 rtl:space-x-reverse h-[60px]">
                       <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center text-[#F08A82] shadow-xl shadow-black/10 shrink-0">
                          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={4} d="M5 13l4 4L19 7" /></svg>
                       </div>
                       <p className="text-white font-black text-2xl tracking-tight">{t(perk)}</p>
                    </div>
                  ))}
               </div>
               <p className="text-white/70 font-medium leading-relaxed max-w-sm text-lg relative z-10 mt-20">{t('maqaseeDesc')}</p>
               <div className="pt-8 relative z-10">
                  <Button onClick={() => navigate('/auth')} className="!bg-white !text-black !px-12 !py-6 !text-sm">{t('tryMaqasee')}</Button>
               </div>
            </div>
         </div>
      </section>

      {/* Footer */}
      <footer className="py-48 px-6 relative overflow-hidden bg-[#89A7A1] text-white rounded-t-[5rem] md:rounded-t-[8rem]">
        <div className="max-w-4xl mx-auto text-center space-y-16 relative z-10">
           <div className="space-y-8">
              <h2 className={`text-6xl md:text-[10rem] font-black text-white tracking-tighter uppercase whitespace-pre-line leading-tight`}>
                {t('readyToFind')}
              </h2>
              <p className="text-2xl text-white/40 font-medium max-w-2xl mx-auto leading-relaxed">
                {t('joinFuture')}
              </p>
           </div>
           <Button onClick={() => navigate('/auth')} className="!py-8 !px-20 !text-sm shadow-heavy !bg-white !text-black hover:scale-105 active:scale-95 transition-all">{t('startJourney')}</Button>
        </div>
        
        <div className="max-w-7xl mx-auto mt-48 pt-20 border-t border-white/20 flex flex-col md:flex-row justify-between items-center space-y-10 md:space-y-0 relative z-10">
           <div className="flex items-center space-x-4 rtl:space-x-reverse">
              <div className="w-12 h-12 bg-white rounded-2xl p-2.5 shadow-2xl"><img src={logoUrl} className="w-full h-full object-contain" /></div>
              <span className="font-black text-2xl tracking-tighter uppercase">{t('appName')}</span>
           </div>
           <p className={`text-[10px] font-black uppercase tracking-[0.5em] text-white ${isRTL ? 'mt-12' : ''}`}>
             {t('footerRights')}
           </p>
        </div>
      </footer>
    </div>
  );
};