import React, { useEffect, useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { Card, Button, Input, useToast, Loading } from '../components/UI';
import { AppLayout } from '../components/Layout';
import { useNavigate } from 'react-router-dom';
import { auth } from '../firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { getUserProfile, getSizeCharts, saveSizeChart, deleteSizeChart, getDiscoveryLinks, saveDiscoveryLink, deleteDiscoveryLink } from '../services/firestore';
import { SizeChart, Gender, Measurements, DiscoveryLink } from '../types';
import { ICONS } from '../constants';

type AdminTab = 'charts' | 'links';

export const Admin: React.FC = () => {
  const { t, isRTL } = useLanguage();
  const { showToast } = useToast();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<AdminTab>('charts');
  
  const [charts, setCharts] = useState<SizeChart[]>([]);
  const [editingChart, setEditingChart] = useState<Partial<SizeChart> | null>(null);
  
  const [links, setLinks] = useState<DiscoveryLink[]>([]);
  const [editingLink, setEditingLink] = useState<Partial<DiscoveryLink> | null>(null);

  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        const userData = await getUserProfile(user.uid);
        if (userData?.isAdmin) {
          setIsAdmin(true);
          const [chartsData, linksData] = await Promise.all([
            getSizeCharts(),
            getDiscoveryLinks()
          ]);
          setCharts(chartsData);
          setLinks(linksData);
        } else {
          showToast("Access Denied");
          navigate('/app');
        }
      } else {
        navigate('/auth');
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, [navigate]);

  const handleSaveChart = async () => {
    if (!editingChart?.platform || !editingChart?.category) {
      showToast("Missing required fields");
      return;
    }
    setLoading(true);
    try {
      await saveSizeChart(editingChart as SizeChart);
      const data = await getSizeCharts();
      setCharts(data);
      setEditingChart(null);
      showToast(t('successSave'));
    } catch (err) {
      console.error(err);
      showToast("Error saving chart");
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteChart = async (id: string) => {
    if (!window.confirm(t('confirmDelete'))) return;
    setLoading(true);
    try {
      await deleteSizeChart(id);
      const data = await getSizeCharts();
      setCharts(data);
      showToast(t('successSave'));
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveLink = async () => {
    if (!editingLink?.platform || !editingLink?.category || !editingLink?.url) {
      showToast("Missing required fields");
      return;
    }
    setLoading(true);
    try {
      await saveDiscoveryLink(editingLink as DiscoveryLink);
      const data = await getDiscoveryLinks();
      setLinks(data);
      setEditingLink(null);
      showToast(t('successSave'));
    } catch (err) {
      console.error(err);
      showToast("Error saving link");
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteLink = async (id: string) => {
    if (!window.confirm(t('confirmDelete'))) return;
    setLoading(true);
    try {
      await deleteDiscoveryLink(id);
      const data = await getDiscoveryLinks();
      setLinks(data);
      showToast(t('successSave'));
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const addSizeRow = () => {
    if (!editingChart) return;
    const newSizes = [...(editingChart.sizes || []), { label: '', ranges: {} }];
    setEditingChart({ ...editingChart, sizes: newSizes });
  };

  if (loading && !isAdmin) return <div className="h-screen flex items-center justify-center bg-zinc-50"><Loading /></div>;

  return (
    <AppLayout showNav={false}>
      <div className="space-y-8 pb-12">
        <header className="flex items-center justify-between">
          <div className="flex items-center space-x-3 rtl:space-x-reverse">
             <button onClick={() => navigate('/app')} className="p-2 -ml-2 text-black active:scale-90 transition-transform">
               <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d={isRTL ? "M9 5l7 7-7 7" : "M15 19l-7-7 7-7"} />
               </svg>
             </button>
             <h1 className="text-2xl font-black text-black">{t('adminPanel')}</h1>
          </div>
          <Button variant="secondary" onClick={() => activeTab === 'charts' ? setEditingChart({ platform: '', category: '', gender: 'women', sizes: [] }) : setEditingLink({ platform: '', category: '', url: '' })} className="!text-[10px] !px-4">
            {activeTab === 'charts' ? t('addChart') : t('addProfile')}
          </Button>
        </header>

        <div className="flex bg-zinc-200/40 p-1 rounded-2xl w-fit mx-auto border border-zinc-200/60">
          <button 
            onClick={() => setActiveTab('charts')}
            className={`px-6 py-2 rounded-xl text-[10px] font-black uppercase transition-all ${activeTab === 'charts' ? 'bg-white text-black shadow-sm' : 'text-zinc-500'}`}
          >
            {t('manageCharts')}
          </button>
          <button 
            onClick={() => setActiveTab('links')}
            className={`px-6 py-2 rounded-xl text-[10px] font-black uppercase transition-all ${activeTab === 'links' ? 'bg-white text-black shadow-sm' : 'text-zinc-500'}`}
          >
            {t('discoveryLinks')}
          </button>
        </div>

        {activeTab === 'charts' && (
          <>
            <div className="grid grid-cols-2 gap-5">
               {/* Total Charts Box (Soft Pink #F6CDC4) */}
               <Card className="flex flex-col justify-between h-32 bg-[#F6CDC4] border-none shadow-[0_20px_40px_-15px_rgba(246,205,196,0.25)]">
                  <span className="text-[10px] font-black uppercase tracking-widest text-zinc-900/60">{t('totalCharts')}</span>
                  <span className="text-5xl font-black text-black tracking-tighter">{charts.length}</span>
               </Card>
               {/* Active Platforms Box (Sage #89A7A1) */}
               <Card className="flex flex-col justify-between h-32 bg-[#89A7A1] border-none shadow-[0_20px_40px_-15px_rgba(137,167,161,0.2)]">
                  <span className="text-[10px] font-black uppercase tracking-widest text-zinc-900/60">{t('activePlatforms')}</span>
                  <span className="text-5xl font-black text-black tracking-tighter">{new Set(charts.map(c => c.platform)).size}</span>
               </Card>
            </div>

            {editingChart ? (
              <Card className="space-y-6 animate-in slide-in-from-bottom-4 duration-500">
                 <div className="flex justify-between items-center">
                    <h2 className="text-lg font-black text-black">{editingChart.id ? t('editChart') : t('addChart')}</h2>
                    <button onClick={() => setEditingChart(null)} className="text-zinc-400">{ICONS.add("w-6 h-6 rotate-45")}</button>
                 </div>
                 <div className="grid grid-cols-2 gap-4">
                    <Input label={t('platformName')} value={editingChart.platform} onChange={e => setEditingChart({...editingChart, platform: e.target.value})} />
                    <Input label={t('category')} value={editingChart.category} onChange={e => setEditingChart({...editingChart, category: e.target.value})} />
                 </div>
                 
                 <div className="space-y-2">
                    <label className="text-xs font-semibold text-zinc-500">{t('gender')}</label>
                    <div className="grid grid-cols-2 gap-2">
                       {(['men', 'women'] as Gender[]).map(g => (
                         <button key={g} onClick={() => setEditingChart({...editingChart, gender: g})} className={`py-2 rounded-xl text-[10px] font-black uppercase transition-all shadow-sm ${editingChart.gender === g ? 'bg-[#F1B95B] text-white shadow-md' : 'bg-zinc-50 text-zinc-400'}`}>{t(g as any)}</button>
                       ))}
                    </div>
                 </div>

                 <div className="space-y-4">
                    <div className="flex justify-between items-center">
                       <h3 className="text-sm font-black text-black">{t('measurements')}</h3>
                       <button onClick={addSizeRow} className="text-xs font-black text-pink-500 uppercase">+ Add Size</button>
                    </div>
                    
                    <div className="space-y-4 max-h-96 overflow-y-auto pr-2 custom-scrollbar">
                       {editingChart.sizes?.map((size, sIdx) => (
                         <div key={sIdx} className="p-4 bg-zinc-50 rounded-2xl space-y-3 relative">
                            <button 
                               onClick={() => {
                                  const newSizes = [...(editingChart.sizes || [])];
                                  newSizes.splice(sIdx, 1);
                                  setEditingChart({...editingChart, sizes: newSizes});
                               }}
                               className="absolute top-2 right-2 text-zinc-300 hover:text-red-400"
                            >
                               ×
                            </button>
                            <Input label="Size Label (e.g. M, 38)" value={size.label} onChange={e => {
                               const newSizes = [...(editingChart.sizes || [])];
                               newSizes[sIdx].label = e.target.value;
                               setEditingChart({...editingChart, sizes: newSizes});
                            }} />
                            
                            <div className="grid grid-cols-2 gap-2">
                               {['chest_cm', 'waist_cm', 'height_cm', 'foot_cm'].map(field => (
                                  <div key={field} className="space-y-1">
                                     <span className="text-[9px] font-black uppercase text-zinc-400">{t(field.split('_')[0] as any)}</span>
                                     <div className="flex items-center space-x-1">
                                        <input 
                                           placeholder="min"
                                           className="w-full bg-white border border-zinc-100 rounded-lg p-1 text-xs"
                                           value={size.ranges[field as keyof Measurements]?.min || ''}
                                           onChange={e => {
                                              const newSizes = [...(editingChart.sizes || [])];
                                              const ranges = {...newSizes[sIdx].ranges};
                                              ranges[field as keyof Measurements] = { min: Number(e.target.value), max: ranges[field as keyof Measurements]?.max || 0 };
                                              newSizes[sIdx].ranges = ranges;
                                              setEditingChart({...editingChart, sizes: newSizes});
                                           }}
                                        />
                                        <input 
                                           placeholder="max"
                                           className="w-full bg-white border border-zinc-100 rounded-lg p-1 text-xs"
                                           value={size.ranges[field as keyof Measurements]?.max || ''}
                                           onChange={e => {
                                              const newSizes = [...(editingChart.sizes || [])];
                                              const ranges = {...newSizes[sIdx].ranges};
                                              ranges[field as keyof Measurements] = { min: ranges[field as keyof Measurements]?.min || 0, max: Number(e.target.value) };
                                              newSizes[sIdx].ranges = ranges;
                                              setEditingChart({...editingChart, sizes: newSizes});
                                           }}
                                        />
                                     </div>
                                  </div>
                               ))}
                            </div>
                         </div>
                       ))}
                    </div>
                 </div>

                 <Button onClick={handleSaveChart} fullWidth>{t('save')}</Button>
              </Card>
            ) : (
              <div className="space-y-4">
                 <h3 className="text-sm font-black uppercase tracking-widest text-zinc-500 px-2">{t('manageCharts')}</h3>
                 <div className="grid grid-cols-1 gap-3">
                    {charts.map(chart => (
                      <Card key={chart.id} className="flex items-center justify-between p-5 border border-zinc-50 hover:border-zinc-200 transition-colors">
                         <div className="flex items-center space-x-4 rtl:space-x-reverse">
                            <div className="w-12 h-12 bg-zinc-50 rounded-2xl flex items-center justify-center font-black text-zinc-400 uppercase">
                               {chart.platform.charAt(0)}
                            </div>
                            <div>
                               <h4 className="font-black text-sm capitalize text-black">{chart.platform} • {t(chart.category as any)}</h4>
                               <p className="text-[9px] font-bold text-zinc-500 uppercase tracking-widest">{t(chart.gender as any)} • {chart.sizes.length} Sizes</p>
                            </div>
                         </div>
                         <div className="flex items-center space-x-2 rtl:space-x-reverse">
                            <button onClick={() => setEditingChart(chart)} className="p-2 text-zinc-400 hover:text-black transition-colors">{ICONS.compare("w-5 h-5")}</button>
                            <button onClick={() => chart.id && handleDeleteChart(chart.id)} className="p-2 text-zinc-400 hover:text-pink-500 transition-colors">
                               <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                            </button>
                         </div>
                      </Card>
                    ))}
                 </div>
              </div>
            )}
          </>
        )}

        {activeTab === 'links' && (
          <>
             {editingLink ? (
                <Card className="space-y-6 animate-in slide-in-from-bottom-4 duration-500">
                   <div className="flex justify-between items-center">
                      <h2 className="text-lg font-black text-black">{editingLink.id ? "Edit Link" : "Add Link"}</h2>
                      <button onClick={() => setEditingLink(null)} className="text-zinc-400">{ICONS.add("w-6 h-6 rotate-45")}</button>
                   </div>
                   <div className="grid grid-cols-1 gap-4">
                      <Input label="Category (e.g. tops, bottoms, abaya)" value={editingLink.category} onChange={e => setEditingLink({...editingLink, category: e.target.value.toLowerCase()})} />
                      <Input label="Platform Name" value={editingLink.platform} onChange={e => setEditingLink({...editingLink, platform: e.target.value})} />
                      <Input label="Affiliate/Store URL" value={editingLink.url} onChange={e => setEditingLink({...editingLink, url: e.target.value})} />
                      <Input label="Button Label (Optional)" placeholder="Shop Now" value={editingLink.label} onChange={e => setEditingLink({...editingLink, label: e.target.value})} />
                   </div>
                   <Button onClick={handleSaveLink} fullWidth>{t('save')}</Button>
                </Card>
             ) : (
                <div className="space-y-4">
                   <h3 className="text-sm font-black uppercase tracking-widest text-zinc-500 px-2">{t('discoveryLinks')}</h3>
                   <div className="grid grid-cols-1 gap-3">
                      {links.map(link => (
                        <Card key={link.id} className="flex items-center justify-between p-5 border border-zinc-50 hover:border-zinc-200 transition-colors">
                           <div className="flex items-center space-x-4 rtl:space-x-reverse">
                              <div className="w-12 h-12 bg-zinc-50 rounded-2xl flex items-center justify-center font-black text-zinc-400 uppercase">
                                 {link.platform.charAt(0)}
                              </div>
                              <div className="max-w-[180px]">
                                 <h4 className="font-black text-sm capitalize text-black">{link.platform} • {t(link.category as any) || link.category}</h4>
                                 <p className="text-[9px] font-bold text-blue-400 uppercase tracking-widest truncate">{link.url}</p>
                              </div>
                           </div>
                           <div className="flex items-center space-x-2 rtl:space-x-reverse">
                              <button onClick={() => setEditingLink(link)} className="p-2 text-zinc-400 hover:text-black transition-colors">{ICONS.compare("w-5 h-5")}</button>
                              <button onClick={() => link.id && handleDeleteLink(link.id)} className="p-2 text-zinc-400 hover:text-pink-500 transition-colors">
                                 <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                           </button>
                           </div>
                        </Card>
                      ))}
                   </div>
                </div>
             )}
          </>
        )}
      </div>
    </AppLayout>
  );
};