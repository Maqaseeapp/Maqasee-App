
import { Measurements, SizeChart, FitPreference, StretchTolerance } from '../types';

export const SEED_CHARTS: SizeChart[] = [
  {
    platform: 'shein',
    category: 'tops',
    gender: 'women',
    sizes: [
      { label: 'XS', ranges: { chest_cm: { min: 78, max: 82 }, waist_cm: { min: 60, max: 64 } } },
      { label: 'S', ranges: { chest_cm: { min: 82, max: 86 }, waist_cm: { min: 64, max: 68 } } },
      { label: 'M', ranges: { chest_cm: { min: 86, max: 90 }, waist_cm: { min: 68, max: 72 } } },
      { label: 'L', ranges: { chest_cm: { min: 90, max: 96 }, waist_cm: { min: 72, max: 78 } } },
      { label: 'XL', ranges: { chest_cm: { min: 96, max: 102 }, waist_cm: { min: 78, max: 84 } } },
    ]
  },
  {
    platform: 'shein',
    category: 'bottoms',
    gender: 'men',
    sizes: [
      { label: 'S', ranges: { waist_cm: { min: 70, max: 76 }, inseam_cm: { min: 74, max: 76 } } },
      { label: 'M', ranges: { waist_cm: { min: 76, max: 82 }, inseam_cm: { min: 76, max: 78 } } },
      { label: 'L', ranges: { waist_cm: { min: 82, max: 88 }, inseam_cm: { min: 78, max: 80 } } },
      { label: 'XL', ranges: { waist_cm: { min: 88, max: 94 }, inseam_cm: { min: 80, max: 82 } } },
    ]
  },
  {
    platform: 'shein',
    category: 'dresses',
    gender: 'women',
    sizes: [
      { label: 'S', ranges: { chest_cm: { min: 82, max: 86 }, waist_cm: { min: 64, max: 68 }, hips_cm: { min: 88, max: 92 } } },
      { label: 'M', ranges: { chest_cm: { min: 86, max: 90 }, waist_cm: { min: 68, max: 72 }, hips_cm: { min: 92, max: 96 } } },
      { label: 'L', ranges: { chest_cm: { min: 90, max: 96 }, waist_cm: { min: 72, max: 78 }, hips_cm: { min: 96, max: 102 } } },
    ]
  },
  {
    platform: 'shein',
    category: 'abaya',
    gender: 'women',
    sizes: [
      { label: '52', ranges: { height_cm: { min: 150, max: 155 } } },
      { label: '54', ranges: { height_cm: { min: 156, max: 160 } } },
      { label: '56', ranges: { height_cm: { min: 161, max: 165 } } },
      { label: '58', ranges: { height_cm: { min: 166, max: 170 } } },
      { label: '60', ranges: { height_cm: { min: 171, max: 175 } } },
    ]
  },
  {
    platform: 'generic',
    category: 'dishdasha',
    gender: 'men',
    sizes: [
      { label: '50', ranges: { height_cm: { min: 145, max: 150 } } },
      { label: '52', ranges: { height_cm: { min: 151, max: 155 } } },
      { label: '54', ranges: { height_cm: { min: 156, max: 160 } } },
      { label: '56', ranges: { height_cm: { min: 161, max: 165 } } },
      { label: '58', ranges: { height_cm: { min: 166, max: 170 } } },
      { label: '60', ranges: { height_cm: { min: 171, max: 175 } } },
    ]
  },
  {
    platform: 'shein',
    category: 'shoes',
    gender: 'women',
    sizes: [
      { label: '36', ranges: { foot_cm: { min: 22.5, max: 23 } } },
      { label: '37', ranges: { foot_cm: { min: 23, max: 23.5 } } },
      { label: '38', ranges: { foot_cm: { min: 23.5, max: 24.1 } } },
      { label: '39', ranges: { foot_cm: { min: 24.1, max: 24.8 } } },
      { label: '40', ranges: { foot_cm: { min: 24.8, max: 25.4 } } },
    ]
  },
  {
    platform: 'temu',
    category: 'tops',
    gender: 'women',
    sizes: [
      { label: 'S', ranges: { chest_cm: { min: 80, max: 85 } } },
      { label: 'M', ranges: { chest_cm: { min: 85, max: 90 } } },
      { label: 'L', ranges: { chest_cm: { min: 90, max: 95 } } },
      { label: 'XL', ranges: { chest_cm: { min: 95, max: 100 } } },
    ]
  },
  {
    platform: 'generic',
    category: 'tops',
    gender: 'men',
    sizes: [
      { label: 'S', ranges: { chest_cm: { min: 88, max: 94 } } },
      { label: 'M', ranges: { chest_cm: { min: 94, max: 102 } } },
      { label: 'L', ranges: { chest_cm: { min: 102, max: 110 } } },
      { label: 'XL', ranges: { chest_cm: { min: 110, max: 118 } } },
    ]
  }
];

export function findBestSize(
  userMeasurements: Measurements, 
  chart: SizeChart, 
  fit: FitPreference = 'regular',
  stretch: StretchTolerance = 'medium'
) {
  let bestSize = chart.sizes[0];
  let highestScore = -1;

  for (const size of chart.sizes) {
    let score = 0;
    let matchCount = 0;

    Object.entries(size.ranges).forEach(([key, range]) => {
      const userVal = userMeasurements[key as keyof Measurements];
      if (userVal !== undefined && range) {
        matchCount++;
        
        // Base Match
        if (userVal >= range.min && userVal <= range.max) {
          score += 10;
        } 
        // Logic for being slightly under/over
        else if (userVal < range.min) {
          score += (stretch === 'high') ? 8 : 4; 
        } else {
          const diff = userVal - range.max;
          if (diff < 3 && stretch === 'high') score += 6;
          else score -= 10; 
        }
      }
    });

    if (fit === 'oversized') score += 3;
    if (fit === 'tight') score -= 1;

    const normalizedScore = matchCount > 0 ? (score / (matchCount * 10)) * 100 : 0;

    if (normalizedScore > highestScore) {
      highestScore = normalizedScore;
      bestSize = size;
    }
  }

  return {
    label: bestSize.label,
    confidence: Math.min(100, Math.max(0, Math.round(highestScore))),
  };
}

export function getGlobalPassportSizes(measurements: Measurements) {
  const chest = measurements.chest_cm || 0;
  
  if (chest < 82) return { us: '0-2', uk: '4-6', eu: '32-34', jp: '3-5' };
  if (chest < 88) return { us: '4-6', uk: '8-10', eu: '36-38', jp: '7-9' };
  if (chest < 96) return { us: '8-10', uk: '12-14', eu: '40-42', jp: '11-13' };
  if (chest < 104) return { us: '12-14', uk: '16-18', eu: '44-46', jp: '15-17' };
  return { us: '16-18', uk: '20-22', eu: '48-50', jp: '19-21' };
}
