
import { doc, getDoc, setDoc, updateDoc, collection, addDoc, query, orderBy, limit, getDocs, deleteDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { UserProfile, Measurements, FitPreference, StretchTolerance, Recommendation, Profile, FitFeedback, Relationship, UnitSystem, Gender, SizeChart, DiscoveryLink, ProductResult, NotificationSettings } from '../types';

export const saveUserProfile = async (uid: string, data: Partial<UserProfile>) => {
  const userRef = doc(db, 'users', uid);
  const docSnap = await getDoc(userRef);
  
  if (docSnap.exists()) {
    await updateDoc(userRef, {
      ...data,
      lastUpdated: Date.now()
    });
  } else {
    const usersRef = collection(db, 'users');
    const q = query(usersRef, limit(1));
    const usersSnap = await getDocs(q);
    const isFirstUser = usersSnap.empty;

    const initialProfileId = 'myself';
    await setDoc(userRef, {
      uid,
      name: data.name || 'User',
      activeProfileId: initialProfileId,
      unitPreference: 'metric',
      notificationSettings: {
        appUpdates: true,
        measurementReminders: true,
        featureAnnouncements: false
      },
      lastUpdated: Date.now(),
      isAdmin: isFirstUser
    });
    await createProfile(uid, initialProfileId, 'Myself', 'women');
  }
};

export const updateUserUnits = async (uid: string, units: UnitSystem) => {
  const userRef = doc(db, 'users', uid);
  await updateDoc(userRef, { unitPreference: units });
};

export const updateNotificationSettings = async (uid: string, settings: NotificationSettings) => {
  const userRef = doc(db, 'users', uid);
  await updateDoc(userRef, { notificationSettings: settings });
};

export const getUserProfile = async (uid: string): Promise<UserProfile | null> => {
  const userRef = doc(db, 'users', uid);
  const docSnap = await getDoc(userRef);
  if (docSnap.exists()) return docSnap.data() as UserProfile;
  return null;
};

export const createProfile = async (uid: string, profileId: string, name: string, gender: Gender = 'women') => {
  const profileRef = doc(db, 'users', uid, 'profiles', profileId);
  await setDoc(profileRef, {
    id: profileId,
    name,
    gender,
    measurements: {},
    fitPreference: 'regular',
    stretchTolerance: 'medium',
    createdAt: Date.now()
  });
};

export const deleteProfile = async (uid: string, profileId: string) => {
  const profileRef = doc(db, 'users', uid, 'profiles', profileId);
  await deleteDoc(profileRef);
};

export const updateProfileMeta = async (uid: string, profileId: string, data: { name: string; type: Relationship; gender?: Gender }) => {
  const profileRef = doc(db, 'users', uid, 'profiles', profileId);
  await updateDoc(profileRef, data);
};

export const getProfiles = async (uid: string): Promise<Profile[]> => {
  const profilesRef = collection(db, 'users', uid, 'profiles');
  const snap = await getDocs(profilesRef);
  return snap.docs.map(doc => doc.data() as Profile);
};

export const getProfile = async (uid: string, profileId: string): Promise<Profile | null> => {
  const profileRef = doc(db, 'users', uid, 'profiles', profileId);
  const snap = await getDoc(profileRef);
  return snap.exists() ? snap.data() as Profile : null;
};

export const updateActiveProfile = async (uid: string, profileId: string) => {
  const userRef = doc(db, 'users', uid);
  await updateDoc(userRef, { activeProfileId: profileId });
};

export const updateProfileMeasurements = async (uid: string, profileId: string, measurements: Measurements) => {
  const profileRef = doc(db, 'users', uid, 'profiles', profileId);
  await updateDoc(profileRef, { measurements });
};

export const updateProfileFit = async (uid: string, profileId: string, fit: FitPreference) => {
  const profileRef = doc(db, 'users', uid, 'profiles', profileId);
  await updateDoc(profileRef, { fitPreference: fit });
};

export const updateProfileStretch = async (uid: string, profileId: string, stretch: StretchTolerance) => {
  const profileRef = doc(db, 'users', uid, 'profiles', profileId);
  await updateDoc(profileRef, { stretchTolerance: stretch });
};

export const saveRecommendation = async (uid: string, profileId: string, rec: Omit<Recommendation, 'id' | 'profileId' | 'timestamp'>) => {
  const recsRef = collection(db, 'users', uid, 'recommendations');
  await addDoc(recsRef, {
    ...rec,
    profileId,
    timestamp: Date.now()
  });
};

export const saveSnapShopResult = async (uid: string, results: ProductResult[]) => {
  const snapRef = collection(db, 'users', uid, 'snapshop_history');
  for (const product of results) {
    await addDoc(snapRef, {
      ...product,
      timestamp: Date.now()
    });
  }
};

export const getSnapShopHistory = async (uid: string): Promise<ProductResult[]> => {
    const snapRef = collection(db, 'users', uid, 'snapshop_history');
    const q = query(snapRef, orderBy('timestamp', 'desc'), limit(20));
    const snap = await getDocs(q);
    return snap.docs.map(doc => doc.data() as ProductResult);
};

export const updateRecommendationFeedback = async (uid: string, recId: string, feedback: FitFeedback) => {
  const recRef = doc(db, 'users', uid, 'recommendations', recId);
  await updateDoc(recRef, { feedback });
};

export const getRecentRecommendation = async (uid: string, profileId: string): Promise<Recommendation | null> => {
  const recsRef = collection(db, 'users', uid, 'recommendations');
  const q = query(recsRef, orderBy('timestamp', 'desc'), limit(10));
  const snap = await getDocs(q);
  
  const matches = snap.docs
    .map(doc => ({ id: doc.id, ...doc.data() } as Recommendation))
    .filter(r => r.profileId === profileId);

  return matches.length > 0 ? matches[0] : null;
};

export const getAllRecommendations = async (uid: string, profileId: string): Promise<Recommendation[]> => {
  const recsRef = collection(db, 'users', uid, 'recommendations');
  const q = query(recsRef, orderBy('timestamp', 'desc'));
  const snap = await getDocs(q);
  return snap.docs
    .map(doc => ({ id: doc.id, ...doc.data() } as Recommendation))
    .filter(r => r.profileId === profileId);
};

// --- Chart Management (Admin) ---

export const getSizeCharts = async (): Promise<SizeChart[]> => {
  const chartsRef = collection(db, 'sizeCharts');
  const snap = await getDocs(chartsRef);
  return snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as SizeChart));
};

export const saveSizeChart = async (chart: SizeChart) => {
  const chartsRef = collection(db, 'sizeCharts');
  if (chart.id) {
    const chartRef = doc(db, 'sizeCharts', chart.id);
    await setDoc(chartRef, chart);
  } else {
    await addDoc(chartsRef, chart);
  }
};

export const deleteSizeChart = async (chartId: string) => {
  const chartRef = doc(db, 'sizeCharts', chartId);
  await deleteDoc(chartRef);
};

// --- Discovery Link Management (Admin) ---

export const getDiscoveryLinks = async (): Promise<DiscoveryLink[]> => {
  const linksRef = collection(db, 'discoveryLinks');
  const snap = await getDocs(linksRef);
  return snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as DiscoveryLink));
};

export const saveDiscoveryLink = async (link: DiscoveryLink) => {
  const linksRef = collection(db, 'discoveryLinks');
  if (link.id) {
    const linkRef = doc(db, 'discoveryLinks', link.id);
    await setDoc(linkRef, link);
  } else {
    await addDoc(linksRef, link);
  }
};

export const deleteDiscoveryLink = async (linkId: string) => {
  const linkRef = doc(db, 'discoveryLinks', linkId);
  await deleteDoc(linkRef);
};
