import React, { ReactNode, useState, useEffect, createContext, useContext } from 'react';
import { useLanguage } from '../context/LanguageContext';

// Toast Context
interface ToastContextType {
  showToast: (message: string) => void;
}
const ToastContext = createContext<ToastContextType | undefined>(undefined);

export const ToastProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [toast, setToast] = useState<string | null>(null);

  const showToast = (message: string) => {
    setToast(message);
    setTimeout(() => setToast(null), 3000);
  };

  return (
    <ToastContext.Provider value={{ showToast }}>
      {children}
      {toast && (
        <div className="fixed top-12 left-1/2 -translate-x-1/2 z-[100] animate-in slide-in-from-top-4 duration-300">
          <div className="bg-[#F08A82]/95 backdrop-blur-md text-white px-8 py-4 rounded-full shadow-[0_25px_50px_-10px_rgba(240,138,130,0.7),0_10px_20px_-5px_rgba(240,138,130,0.5)] text-[10px] font-black uppercase tracking-widest whitespace-nowrap border border-zinc-800/20">
            {toast}
          </div>
        </div>
      )}
    </ToastContext.Provider>
  );
};

export const useToast = () => {
  const context = useContext(ToastContext);
  if (!context) throw new Error('useToast must be used within ToastProvider');
  return context;
};

// Unified Loading Component with Custom Spin Icon
export const Loading: React.FC = () => {
  const loadingIconUrl = "https://i.postimg.cc/B6MP4TRj/Spin.png";
  return (
    <div className="min-h-[40vh] flex flex-col items-center justify-center p-8">
      <div className="relative w-24 h-24">
        {/* Soft pulsing glow effect matching Salmon accent */}
        <div className="absolute inset-0 bg-[#F08A82]/30 rounded-full blur-3xl animate-pulse scale-150"></div>
        {/* Animated Spin Icon */}
        <img 
          src={loadingIconUrl} 
          className="w-full h-full object-contain animate-[spin_3s_linear_infinite] drop-shadow-2xl" 
          alt="Loading..." 
        />
      </div>
    </div>
  );
};

interface CardProps {
  children: ReactNode;
  className?: string;
  bgColor?: string;
  hasBlur?: boolean;
}

export const Card: React.FC<CardProps> = ({ children, className = "", bgColor = "bg-white", hasBlur = false }) => (
  <div className={`
    rounded-[2.5rem] p-6 
    shadow-[0_35px_70px_-15px_rgba(0,0,0,0.1),0_20px_40px_-20px_rgba(0,0,0,0.1),0_0_1px_rgba(0,0,0,0.1)] 
    border border-zinc-300
    ring-1 ring-zinc-900/[0.04]
    ${hasBlur ? 'backdrop-blur-xl' : 'backdrop-blur-sm'}
    ${bgColor} ${className}
    transition-all duration-500 hover:shadow-[0_45px_80px_-20px_rgba(0,0,0,0.12),0_25px_45px_-25px_rgba(0,0,0,0.12)]
  `}>
    {children}
  </div>
);

interface ButtonProps {
  children: ReactNode;
  onClick?: () => void;
  className?: string;
  variant?: 'primary' | 'secondary' | 'ghost';
  fullWidth?: boolean;
  disabled?: boolean;
}

export const Button: React.FC<ButtonProps> = ({ 
  children, 
  onClick, 
  className = "", 
  variant = 'primary',
  fullWidth = false,
  disabled = false
}) => {
  const baseClasses = "rounded-full px-8 py-4 font-black text-[10px] uppercase tracking-[0.15em] transition-all duration-300 active:scale-95 disabled:opacity-50 disabled:active:scale-100 border";
  
  // Refined Primary Button with Salmon (#F08A82) glow
  const variants = {
    primary: "bg-[#F08A82] text-white border-zinc-800/10 hover:opacity-95 shadow-[0_25px_50px_-12px_rgba(240,138,130,0.7),0_12px_24px_-8px_rgba(240,138,130,0.5),0_0_0_1px_rgba(255,255,255,0.4)_inset] hover:shadow-[0_35px_65px_-10px_rgba(240,138,130,0.85),0_18px_35px_-5px_rgba(240,138,130,0.6),0_0_0_1px_rgba(255,255,255,0.5)_inset]",
    secondary: "bg-white text-zinc-900 border-zinc-400 shadow-[0_15px_30px_-10px_rgba(0,0,0,0.06),0_8px_16px_-8px_rgba(0,0,0,0.05)] ring-1 ring-zinc-900/[0.02] hover:bg-zinc-50 hover:border-zinc-500 hover:shadow-[0_20px_40px_-10px_rgba(0,0,0,0.08)]",
    ghost: "bg-transparent text-zinc-600 border-transparent hover:text-[#F08A82]"
  };

  return (
    <button 
      onClick={onClick} 
      disabled={disabled}
      className={`${baseClasses} ${variants[variant]} ${fullWidth ? 'w-full' : ''} ${className}`}
    >
      {children}
    </button>
  );
};

export const FloatingActionButton: React.FC<{ onClick: () => void }> = ({ onClick }) => (
  <button 
    onClick={onClick}
    className="fixed bottom-24 left-1/2 -translate-x-1/2 w-16 h-16 bg-[#F08A82] text-white rounded-full flex items-center justify-center shadow-[0_30px_60px_-12px_rgba(240,138,130,0.8),0_10px_20px_-5px_rgba(240,138,130,0.5),0_0_0_1px_rgba(255,255,255,0.4)_inset] active:scale-90 transition-all z-50 border-4 border-zinc-300"
  >
    <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
    </svg>
  </button>
);

export const Input = React.forwardRef<HTMLInputElement, {
  label?: string;
  type?: string;
  placeholder?: string;
  value?: string | number;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  className?: string;
  name?: string;
  onBlur?: (e: React.FocusEvent<HTMLInputElement>) => void;
}>(({ label, type = "text", placeholder, value, onChange, className = "", name, onBlur }, ref) => (
  <div className={`space-y-2 ${className}`}>
    {label && <label className="text-[10px] font-black text-zinc-600 px-2 uppercase tracking-[0.2em]">{label}</label>}
    <div className="relative group">
      <input 
        ref={ref}
        name={name}
        onBlur={onBlur}
        type={type}
        placeholder={placeholder}
        value={value}
        onChange={onChange}
        className="w-full bg-zinc-50/70 border border-zinc-300 rounded-3xl px-6 py-4 text-sm font-bold text-zinc-900 placeholder:text-zinc-400 focus:outline-none focus:ring-2 focus:ring-[#F08A82]/10 focus:bg-white transition-all appearance-none ring-1 ring-zinc-900/[0.02] shadow-[0_10px_20px_-10px_rgba(0,0,0,0.03)]"
      />
    </div>
  </div>
));

Input.displayName = 'Input';