import React, { ReactNode, useState, useEffect } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { ICONS } from '../constants';
import { useLocation, useNavigate } from 'react-router-dom';
import { auth } from '../firebase';
import { getUserProfile } from '../services/firestore';
import { onAuthStateChanged } from 'firebase/auth';

interface LayoutProps {
  children: ReactNode;
  showNav?: boolean;
}

export const AppLayout: React.FC<LayoutProps> = ({ children, showNav = true }) => {
  const { t, isRTL, language, setLanguage } = useLanguage();
  const location = useLocation();
  const navigate = useNavigate();
  const [isOffline, setIsOffline] = useState(!navigator.onLine);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        const profile = await getUserProfile(user.uid);
        setIsAdmin(!!profile?.isAdmin);
      } else {
        setIsAdmin(false);
      }
    });

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      unsubscribe();
    };
  }, []);

  const navItems = [
    { id: 'dashboard', path: '/app', icon: ICONS.dashboard, label: t('dashboard') },
    { id: 'discover', path: '/app/discover', icon: ICONS.discover, label: t('discover') },
    { id: 'size-finder', path: '/app/size-finder', icon: ICONS.sizeFinder, label: t('sizeFinder') },
    { id: 'profile', path: '/app/profile', icon: ICONS.profile, label: t('profile') },
  ];

  if (isAdmin) {
    navItems.push({ id: 'admin', path: '/admin', icon: ICONS.admin, label: t('admin') });
  }

  // Unified logo for all languages
  const logoUrl = "https://i.postimg.cc/tCD6Wpcg/Chat-GPT-Image-Jan-30-2026-02-19-49-PM.png";

  return (
    <div className="min-h-screen flex flex-col bg-[#F7F1E5] selection:bg-[#F08A82]/10">
      {/* Offline Banner */}
      {isOffline && (
        <div className="bg-[#FEF9E7] border-b border-yellow-100 py-2 px-4 flex items-center justify-center space-x-2 rtl:space-x-reverse sticky top-0 z-[60] animate-in slide-in-from-top-4">
           <span className="w-2 h-2 bg-yellow-600 rounded-full animate-pulse"></span>
           <p className="text-[10px] font-black uppercase text-yellow-800 tracking-widest">
             {t('offlineMode')} - {t('usingCache')}
           </p>
        </div>
      )}

      {/* Persistent Global Header */}
      <header className="max-w-lg mx-auto w-full px-6 pt-6 flex justify-between items-center shrink-0">
        <div className="flex items-center space-x-2 rtl:space-x-reverse cursor-pointer" onClick={() => navigate('/app')}>
          <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center overflow-hidden shadow-[0_4px_20px_-5px_rgba(0,0,0,0.05)] border border-white ring-1 ring-zinc-900/[0.03] p-0.5">
             <img src={logoUrl} alt="Maqasee" className="w-full h-full object-contain" />
          </div>
          <span className="font-bold text-sm tracking-tight text-black">{t('appName')}</span>
        </div>
        
        {/* Language Switcher Button */}
        <div className="flex bg-zinc-200/40 p-1 rounded-full border border-zinc-200/60 ring-1 ring-white">
          <button 
            onClick={() => setLanguage('en')}
            className={`px-3 py-1 rounded-full text-[10px] font-bold transition-all ${language === 'en' ? 'bg-white text-black shadow-sm ring-1 ring-zinc-900/[0.02]' : 'text-zinc-500'}`}
          >
            EN
          </button>
          <button 
            onClick={() => setLanguage('ar')}
            className={`px-3 py-1 rounded-full text-[10px] font-bold transition-all ${language === 'ar' ? 'bg-white text-black shadow-sm ring-1 ring-zinc-900/[0.02]' : 'text-zinc-500'}`}
          >
            AR
          </button>
        </div>
      </header>

      <main className="flex-1 max-w-lg mx-auto w-full px-6 pt-4 pb-32 overflow-visible">
        {children}
      </main>

      {showNav && (
        <nav className="fixed bottom-8 left-1/2 -translate-x-1/2 w-[92%] max-w-md bg-white/80 backdrop-blur-2xl border border-white/60 ring-1 ring-zinc-900/[0.06] rounded-[2.5rem] p-2 flex justify-between items-center shadow-[0_25px_60px_-15px_rgba(0,0,0,0.1)] z-40">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <button
                key={item.id}
                onClick={() => navigate(item.path)}
                className={`flex flex-col items-center justify-center space-y-1 px-3 py-2 rounded-full transition-all flex-1 ${
                  isActive ? 'text-[#F08A82]' : 'text-zinc-400 hover:text-zinc-600'
                }`}
              >
                {item.icon("w-5 h-5")}
                {isActive && <span className="text-[9px] font-black uppercase tracking-wider truncate animate-in fade-in slide-in-from-bottom-1 duration-300">{item.label}</span>}
              </button>
            );
          })}
        </nav>
      )}
    </div>
  );
};